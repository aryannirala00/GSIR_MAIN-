# AI Dashboard — React port

A full conversion of the single-file HTML/CSS/JS dashboard into a proper
Vite + React project. Same look, same features — rebuilt as real components
with centralized state instead of a 7,700-line script full of DOM queries.

## Run it

```bash
npm install
npm run dev       # http://localhost:5173, hot-reloading
npm run build      # production build → dist/
npm run preview    # serve the production build locally
```

No backend required — this is still a front-end mock, same as the original
(search results and AI replies are placeholders; look for "connect your
backend here" comments in the code for exactly where to wire in real calls).

## What changed structurally

**Everything lives in one place now.** All app data — tabs, weblinks,
projects, notes, account, settings — is in a single reducer
(`src/context/reducer.js`) shared through Context, instead of being scattered
across dozens of module-level `let` variables. Every component reads state
and dispatches actions; nothing reaches into the DOM directly anymore.

**React auto-escapes everything.** The vanilla version needed careful manual
`escapeHtml()` calls anywhere user text got inserted into the page — several
of those were missing and caused real XSS holes (fixed in the last pass
before this one). In React, `{someText}` in JSX is escaped by default; the
entire bug class can't happen here unless something deliberately uses
`dangerouslySetInnerHTML`, which nothing in this codebase does.

**Pages are conditionally rendered, not shown/hidden with CSS.** The
original toggled `.active` classes and `display: none` across half a dozen
page containers that all secretly lived in the same DOM tree. Here,
`App.jsx` just renders whichever page component matches `state.page` — simpler,
and it's what fixed (for free) a subtlety the vanilla version had to
carefully guard against: Projects always reopening on its own select screen
rather than resuming a stale wizard/detail view, since each page component
gets fresh local state every time it mounts.

**LocalStorage persistence — new, not in the original.** Weblinks, projects,
notes, account info, and settings now survive a page reload
(`src/context/AppContext.jsx`). Tabs, panels, and toasts intentionally don't
persist — those are meant to reset each session, same as before.

## Project layout

```
src/
  main.jsx                 entry point
  App.jsx                  top-level layout + page routing
  context/
    initialState.js        the whole app's starting data
    reducer.js              every state transition, grouped by feature
    AppContext.jsx          Provider + hooks (useAppState, useAppDispatch, useToast) + localStorage sync
  components/
    Sidebar.jsx             hover pop-out nav
    Header.jsx              new-tab button, tab bar with live numbering
    Message.jsx             chat bubble + action bar (copy/share/branch/continue/citation/like)
    SearchView.jsx / HomeView.jsx   the chat workspace
    TabContentPane.jsx      website/file/note opened "in a tab"
    WeblinkPanel.jsx        quick-access links grid
    ToastStack.jsx / HistoryPanel.jsx / NotificationPanel.jsx
    Account/                4 tabs, avatar cropper, chips, equipment, star ratings
    Notes/                  full CRUD, lazy-loaded grid
    Projects/                4-step wizard, project list, detail view
    Settings/                all 11 categories
  utils/                   icon-by-filename, relative time, url/email helpers
```

## Feature parity notes — what's simplified vs. the original

- **Search scope dropdown** (choosing which Project Knowledge File to search
  within) is simplified to a fixed "All Knowledge" label. The original tied
  this to associating a tab with a specific project; wiring that back in is
  straightforward if you need it — see `SearchView.jsx`.
- **Voice input / audio visualization** are still just toast placeholders,
  same as the original (no real speech backend either way).
- Everything else — tabs, weblinks, projects, notes, account, settings,
  dark mode, font size — is fully interactive, not stubbed.

## How this was verified

Rather than just reading through the code, this was checked with two
automated test passes: one confirms the app mounts cleanly with zero runtime
errors, and a second simulates real clicks/typing through every major
flow — sidebar navigation, tabs, search → AI reply → all 6 message action
buttons, weblinks, the full project wizard through to a saved project card
and detail view, complete notes CRUD (including the empty-title validation
block), account fields/chips/equipment/star ratings, and every Settings
category including dark mode — using adversarial input
(`<img onerror=...>`-style strings) specifically to confirm React's escaping
holds, not just that each feature "works" on friendly text. All passing,
zero console errors.
