import React, { useEffect, useRef, useState } from 'react';
import { useAppState, useAppDispatch, useToast } from '../context/AppContext.jsx';
import { getIconForName } from '../utils/icons.js';
import Message from './Message.jsx';

export default function SearchView({ tab }) {
  const state = useAppState();
  const dispatch = useAppDispatch();
  const showToast = useToast();
  const textareaRef = useRef(null);
  const fileInputRef = useRef(null);
  const conversationRef = useRef(null);
  const collapseTimer = useRef(null);
  const pendingReplyTimer = useRef(null);
  const [dragOver, setDragOver] = useState(false);
  const [toolbarExpanded, setToolbarExpanded] = useState(true);
  const [thinking, setThinking] = useState(false);

  const hasMessages = tab.conversation.length > 0;
  const project = tab.projectId ? state.projects.find((p) => p.id === tab.projectId) : null;

  // Auto-scroll to the newest message, same as any standard chat app.
  useEffect(() => {
    const el = conversationRef.current;
    if (el) el.scrollTop = el.scrollHeight;
  }, [tab.conversation.length, thinking]);

  // Cancel any pending mock reply if you switch away from this tab mid-"thinking".
  useEffect(() => () => clearTimeout(pendingReplyTimer.current), []);

  const autoResize = (el) => {
    el.style.height = 'auto';
    el.style.height = Math.min(el.scrollHeight, 120) + 'px';
  };

  const send = () => {
    const query = tab.query.trim();
    if (!query || thinking) return;

    dispatch({ type: 'ADD_SEARCH_HISTORY', query });
    dispatch({ type: 'ADD_TAB_MESSAGE', message: { role: 'user', text: query, incomplete: false } });
    dispatch({ type: 'RENAME_ACTIVE_TAB', label: query, icon: getIconForName(query) });
    dispatch({ type: 'SET_TAB_QUERY', query: '' });
    if (textareaRef.current) autoResize(textareaRef.current);

    // First message in this tab: collapse the toolbar down to a compact bar,
    // same as any chat app that only shows its full input once, up front.
    setToolbarExpanded(false);
    setThinking(true);

    // Front-end mock only — swap this out for a real backend call.
    // `incomplete: true` is what makes the Continue button appear on the
    // reply — a real backend should set this from its own stop reason.
    pendingReplyTimer.current = setTimeout(() => {
      setThinking(false);
      const scopeNote = project ? `searched: ${project.name}` : 'searched: all your chats';
      dispatch({
        type: 'ADD_TAB_MESSAGE',
        message: {
          role: 'ai',
          text: `Here's what I found for "${query}" (${scopeNote}). This is a placeholder response — connect your backend here.`,
          incomplete: true,
        },
      });
    }, 900);
  };

  const stopGenerating = () => {
    clearTimeout(pendingReplyTimer.current);
    setThinking(false);
    showToast('Stopped', 'default');
  };

  const handleKeyPress = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      send();
    }
  };

  const addFiles = (fileList) => {
    Array.from(fileList).forEach((file) => {
      dispatch({ type: 'ADD_TAB_ATTACHMENT', file: { name: file.name } });
      dispatch({ type: 'RENAME_ACTIVE_TAB', label: file.name, icon: getIconForName(file.name) });
    });
  };

  const onDrop = (e) => {
    e.preventDefault();
    setDragOver(false);
    if (e.dataTransfer?.files?.length) addFiles(e.dataTransfer.files);
  };

  // Collapsed bar (once a conversation is running): click/focus pops the
  // full toolbar back out; it folds back down a beat after you leave it,
  // so picking a mode or hitting attach doesn't instantly collapse under you.
  const expandToolbar = () => {
    clearTimeout(collapseTimer.current);
    setToolbarExpanded(true);
  };
  const collapseToolbarSoon = () => {
    if (!hasMessages) return; // never collapse before the first message — same first-appearance as always
    clearTimeout(collapseTimer.current);
    collapseTimer.current = setTimeout(() => setToolbarExpanded(false), 400);
  };

  const showFullToolbar = toolbarExpanded || !hasMessages;

  return (
    <>
      {!hasMessages && (
        <div className="logo-container">
          <img src="https://via.placeholder.com/180x120?text=AI+Logo" alt="Logo" decoding="async" />
        </div>
      )}

      <div
        className={`search-container${!showFullToolbar ? ' search-collapsed' : ''}`}
        id="searchContainer"
        onDragOver={(e) => { e.preventDefault(); setDragOver(true); }}
        onDragLeave={() => setDragOver(false)}
        onDrop={onDrop}
        onFocus={expandToolbar}
        onBlur={collapseToolbarSoon}
        style={dragOver ? { outline: '2px dashed var(--primary-color)' } : undefined}
      >
        {/* Only shown once this tab is actually scoped to a project's
            knowledge — a plain chat tab shows no scope label at all. */}
        {project && (
          <div className="search-scope-label" id="searchScopeLabel">
            Searching: <strong id="searchScopeLabelText">{project.name} Knowledge</strong>
          </div>
        )}

        {tab.attachedFiles.length > 0 && (
          <div className="attached-files-row" id="attachedFilesRow">
            {tab.attachedFiles.map((f, i) => (
              <span className="attached-file-chip" key={i}>
                <i className={`fas ${getIconForName(f.name)} file-type-icon`}></i>
                {f.name}
                <button type="button" title="Remove" onClick={() => dispatch({ type: 'REMOVE_TAB_ATTACHMENT', index: i })}>
                  <i className="fas fa-xmark"></i>
                </button>
              </span>
            ))}
          </div>
        )}

        <div className="search-wrapper">
          <i className="fas fa-search search-icon"></i>
          <textarea
            ref={textareaRef}
            className="search-input has-scope-btn"
            id="searchInput"
            placeholder="Ask me anything... search, research, ideas, coding..."
            rows={1}
            value={tab.query}
            onChange={(e) => {
              dispatch({ type: 'SET_TAB_QUERY', query: e.target.value });
              autoResize(e.target);
            }}
            onKeyPress={handleKeyPress}
            onFocus={expandToolbar}
          />
          {thinking ? (
            <button className="send-btn send-btn-stop" id="stopBtn" title="Stop generating" onClick={stopGenerating}>
              <i className="fas fa-stop"></i>
            </button>
          ) : (
            <button className="send-btn" id="sendBtn" title="Send" onClick={send}>
              <i className="fas fa-arrow-up"></i>
            </button>
          )}
        </div>

        {/* Compact mode (after the first message, until clicked): just the
            input above and the attach button here — everything else folds
            away until you click back into the bar. */}
        <div className="toolbar" onMouseEnter={expandToolbar}>
          <button className="toolbar-btn" id="addFileBtn" title="Add attachment (PDF, files, etc.)" onClick={() => { expandToolbar(); fileInputRef.current?.click(); }}>
            <i className="fas fa-plus"></i>
          </button>
          <input
            type="file"
            multiple
            ref={fileInputRef}
            style={{ display: 'none' }}
            onChange={(e) => { if (e.target.files.length) addFiles(e.target.files); e.target.value = ''; }}
          />

          {showFullToolbar && (
            <>
              <select className="toolbar-select" id="modeSelector" defaultValue="analysis">
                <option value="analysis">Analysis Mode</option>
                <option value="creative">Creative Mode</option>
                <option value="research">Research Mode</option>
                <option value="casual">Casual Mode</option>
              </select>

              <button className="toolbar-btn" id="voiceBtn" title="Voice input" onClick={() => showToast('Voice input needs a real speech backend — not wired up in this preview', 'default')}>
                <i className="fas fa-microphone"></i>
              </button>
              <button className="toolbar-btn" id="waveBtn" title="Audio visualization" onClick={() => showToast('Audio visualization is not available in this preview', 'default')}>
                <i className="fas fa-wave-square"></i>
              </button>
            </>
          )}
        </div>
      </div>

      <div className={`conversation-area${hasMessages ? ' has-messages' : ''}`} id="conversationArea" ref={conversationRef}>
        {tab.conversation.map((msg, i) => (
          <Message key={i} msg={msg} index={i} />
        ))}
        {thinking && (
          <div className="conv-message ai" aria-live="polite">
            <div className="conv-bubble conv-typing">
              <span></span><span></span><span></span>
            </div>
          </div>
        )}
      </div>
    </>
  );
}
