import React from 'react';
import { getIconForName } from '../utils/icons.js';

export default function TabContentPane({ tab }) {
  const p = tab.payload || {};

  if (tab.type === 'link') {
    const title = p.name || p.url;
    return (
      <div className="tab-content-pane active">
        <div className="tab-content-header">
          <i className="fas fa-globe"></i>
          <span className="tch-title">{title}</span>
          <a href={p.url} target="_blank" rel="noopener noreferrer">Open in new tab ↗</a>
        </div>
        <iframe className="tab-content-frame" src={p.url} title={title} referrerPolicy="no-referrer"></iframe>
        <div style={{ fontSize: 12, color: 'var(--text-light)' }}>
          Some sites don't allow embedding — if this stays blank, use "Open in new tab" above.
        </div>
      </div>
    );
  }

  if (tab.type === 'note') {
    return (
      <div className="tab-content-pane active">
        <div className="tab-content-header">
          <i className="fas fa-note-sticky"></i>
          <span className="tch-title">{p.title || 'Untitled note'}</span>
        </div>
        <div className="tab-content-note">{p.text || '(empty note)'}</div>
      </div>
    );
  }

  // 'file'
  const icon = getIconForName(p.name || '');
  return (
    <div className="tab-content-pane active">
      <div className="tab-content-header">
        <i className={`fas ${icon}`}></i>
        <span className="tch-title">{p.name}</span>
      </div>
      <div className="tab-content-placeholder">
        <i className={`fas ${icon}`}></i>
        <span className="tcp-name">{p.name}</span>
        <span className="tcp-note">This mock keeps only the file's name, not its bytes — connect real file storage to preview it here.</span>
      </div>
    </div>
  );
}
