import React from 'react';
import { useAppState, useAppDispatch } from '../context/AppContext.jsx';

const NOTIFICATIONS = [
  'Your high performance workspace environment loaded successfully.',
  'System synchronization updated completely.',
  'New biotech internship opportunities matching your profile were found.',
];

export default function NotificationPanel() {
  const state = useAppState();
  const dispatch = useAppDispatch();

  return (
    <div className={`notification-panel${state.notificationPanelOpen ? ' active' : ''}`} id="notificationPanel">
      <div className="panel-header">
        <h3 className="panel-title">Notifications</h3>
        <button className="panel-close" id="notificationClose" onClick={() => dispatch({ type: 'TOGGLE_NOTIFICATION_PANEL' })}>✕</button>
      </div>
      <div className="panel-content">
        {NOTIFICATIONS.map((text, i) => (
          <div className="notification-item" key={i}>
            <div className="notification-dot"></div>
            <div className="notification-text">{text}</div>
          </div>
        ))}
      </div>
    </div>
  );
}
