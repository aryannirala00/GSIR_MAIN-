import React, { useState } from 'react';
import { useAppState, useAppDispatch, useToast } from '../../context/AppContext.jsx';

const CATEGORIES = [
  { key: 'general', label: 'General', icon: 'fa-sliders' },
  { key: 'ai', label: 'AI Settings', icon: 'fa-robot' },
  { key: 'account', label: 'Account', icon: 'fa-user' },
  { key: 'integrations', label: 'Connected Apps & Plugins', icon: 'fa-plug' },
  { key: 'privacy', label: 'Privacy & Security', icon: 'fa-shield-halved' },
  { key: 'notifications', label: 'Notifications', icon: 'fa-bell' },
  { key: 'chat', label: 'Chat Settings', icon: 'fa-comments' },
  { key: 'storage', label: 'Files & Storage', icon: 'fa-database' },
  { key: 'accessibility', label: 'Accessibility', icon: 'fa-universal-access' },
  { key: 'voice', label: 'Voice & Audio', icon: 'fa-microphone-lines' },
  { key: 'about', label: 'About & Support', icon: 'fa-circle-info' },
];

function Toggle({ checked, onChange }) {
  return (
    <label className="toggle-switch">
      <input type="checkbox" checked={checked} onChange={(e) => onChange(e.target.checked)} />
      <span className="toggle-slider"></span>
    </label>
  );
}

function Row({ title, desc, children }) {
  return (
    <div className="setting-row">
      <div className="setting-row-label">
        <span className="title">{title}</span>
        {desc && <span className="desc">{desc}</span>}
      </div>
      <div className="setting-row-control">{children}</div>
    </div>
  );
}

const INTEGRATIONS = [
  { name: 'Notion', desc: 'Pull pages and databases into search' },
  { name: 'Google Drive', desc: 'Search across your Drive files' },
  { name: 'Slack', desc: 'Reference recent channel activity' },
];
const PLUGINS = [
  { name: 'Code Interpreter', desc: 'Run and test code snippets inline' },
  { name: 'Web Browsing', desc: 'Let the AI fetch live pages' },
];

export default function SettingsPage() {
  const state = useAppState();
  const dispatch = useAppDispatch();
  const showToast = useToast();
  const [category, setCategory] = useState('general');
  const [connected, setConnected] = useState({});
  const [pluginsOn, setPluginsOn] = useState({});

  const setSetting = (key, value) => dispatch({ type: 'UPDATE_SETTING', key, value });
  const notAvailable = () => showToast('Not available in this preview', 'default');

  return (
    <div className="content">
      <div className="settings-page active" id="settingsPage">
        <div className="account-page-header">
          <h1>Settings</h1>
          <p>Configure how the dashboard looks and behaves.</p>
        </div>

        <div className="settings-layout">
          <div className="settings-nav" id="settingsNav">
            {CATEGORIES.map((c) => (
              <div key={c.key} className={`settings-nav-item${category === c.key ? ' active' : ''}`} onClick={() => setCategory(c.key)}>
                <i className={`fas ${c.icon}`}></i>{c.label}
              </div>
            ))}
          </div>

          <div className="settings-panels" id="settingsPanels">
            {category === 'general' && (
              <div className="settings-panel active">
                <div className="account-section">
                  <h2>General</h2>
                  <p className="section-sub">Language, region, and how the app looks.</p>
                  <Row title="Auto-detect Location" desc="Automatically set your region using your device location">
                    <Toggle checked={state.settings.autoLocation} onChange={(v) => setSetting('autoLocation', v)} />
                  </Row>
                  <Row title="Dark Mode" desc="Switch the whole dashboard to a dark theme">
                    <Toggle checked={state.darkMode} onChange={() => dispatch({ type: 'TOGGLE_DARK_MODE' })} />
                  </Row>
                  <Row title="Font Size">
                    <select value={state.fontSize} onChange={(e) => dispatch({ type: 'SET_FONT_SIZE', size: e.target.value })}>
                      <option value="small">Small</option>
                      <option value="medium">Medium</option>
                      <option value="large">Large</option>
                    </select>
                  </Row>
                  <Row title="Language">
                    <select defaultValue="English" onChange={notAvailable}>
                      {['English', 'Spanish', 'French', 'German', 'Hindi', 'Chinese (Simplified)', 'Japanese', 'Arabic'].map((l) => <option key={l}>{l}</option>)}
                    </select>
                  </Row>
                  <Row title="Region & Time Zone">
                    <select defaultValue="(GMT+00:00) London" onChange={notAvailable}>
                      {['(GMT+00:00) London', '(GMT-05:00) New York', '(GMT-08:00) Los Angeles', '(GMT+01:00) Paris / Berlin', '(GMT+05:30) Mumbai / Delhi', '(GMT+09:00) Tokyo'].map((z) => <option key={z}>{z}</option>)}
                    </select>
                  </Row>
                </div>
              </div>
            )}

            {category === 'ai' && (
              <div className="settings-panel active">
                <div className="account-section">
                  <h2>AI Settings</h2>
                  <p className="section-sub">How the assistant behaves when it replies.</p>
                  <Row title="Remember conversations" desc="Let the AI use earlier chats as context">
                    <Toggle checked={state.settings.memory} onChange={(v) => setSetting('memory', v)} />
                  </Row>
                  <Row title="Auto-suggestions" desc="Show follow-up prompt suggestions">
                    <Toggle checked={state.settings.autoSuggestions} onChange={(v) => setSetting('autoSuggestions', v)} />
                  </Row>
                  <Row title="Web search" desc="Allow the AI to search the web for current info">
                    <Toggle checked={state.settings.webSearch} onChange={(v) => setSetting('webSearch', v)} />
                  </Row>
                  <Row title="Creativity" desc="Lower = more focused, higher = more exploratory">
                    <input type="range" min="0" max="100" value={state.settings.creativity} onChange={(e) => setSetting('creativity', Number(e.target.value))} />
                  </Row>
                </div>
              </div>
            )}

            {category === 'account' && (
              <div className="settings-panel active">
                <div className="account-section">
                  <h2>Account</h2>
                  <Row title="Two-Factor Authentication" desc="Add an extra step when signing in">
                    <Toggle checked={state.settings.twoFA} onChange={(v) => setSetting('twoFA', v)} />
                  </Row>
                  <Row title="Login History"><button className="settings-btn" onClick={notAvailable}>View</button></Row>
                  <Row title="Delete Account" desc="Permanently remove your account and data">
                    <button className="settings-btn settings-btn-danger" onClick={notAvailable}>Delete</button>
                  </Row>
                </div>
              </div>
            )}

            {category === 'integrations' && (
              <div className="settings-panel active">
                <div className="account-section">
                  <h2>Connected Apps & Plugins</h2>
                  <p className="section-sub">Link productivity apps to pull their data in, and turn on plugins that add extra tools inside the dashboard.</p>
                  <div className="settings-subtitle">Connected Apps</div>
                  {INTEGRATIONS.map((app) => (
                    <div className="connected-account-row" key={app.name}>
                      <div className="connected-account-info">
                        <span className="title">{app.name}</span>
                        <span className="desc">{connected[app.name] ? 'Connected' : app.desc}</span>
                      </div>
                      <button className="settings-btn" onClick={() => setConnected((c) => ({ ...c, [app.name]: !c[app.name] }))}>
                        {connected[app.name] ? 'Disconnect' : 'Connect'}
                      </button>
                    </div>
                  ))}
                  <div className="settings-subtitle" style={{ marginTop: 24 }}>Plugins</div>
                  {PLUGINS.map((p) => (
                    <Row title={p.name} desc={pluginsOn[p.name] ? 'Enabled' : p.desc} key={p.name}>
                      <Toggle checked={!!pluginsOn[p.name]} onChange={(v) => setPluginsOn((s) => ({ ...s, [p.name]: v }))} />
                    </Row>
                  ))}
                </div>
              </div>
            )}

            {category === 'privacy' && (
              <div className="settings-panel active">
                <div className="account-section">
                  <h2>Privacy & Security</h2>
                  <Row title="Data Export" desc="Download a copy of everything stored locally"><button className="settings-btn" onClick={notAvailable}>Export</button></Row>
                  <Row title="Clear Local Data" desc="Wipe everything saved in this browser">
                    <button className="settings-btn settings-btn-danger" onClick={() => {
                      if (window.confirm('This clears everything saved locally — weblinks, projects, notes, account, settings. Continue?')) {
                        localStorage.clear();
                        window.location.reload();
                      }
                    }}>Clear</button>
                  </Row>
                </div>
              </div>
            )}

            {category === 'notifications' && (
              <div className="settings-panel active">
                <div className="account-section">
                  <h2>Notifications</h2>
                  <Row title="Push Notifications" desc="Get notified about replies and updates"><Toggle checked={true} onChange={notAvailable} /></Row>
                  <Row title="Email Digest" desc="Weekly summary by email"><Toggle checked={false} onChange={notAvailable} /></Row>
                </div>
              </div>
            )}

            {category === 'chat' && (
              <div className="settings-panel active">
                <div className="account-section">
                  <h2>Chat Settings</h2>
                  <Row title="Chat History" desc="Keep a record of past conversations"><Toggle checked={true} onChange={notAvailable} /></Row>
                  <Row title="Clear Chat History"><button className="settings-btn settings-btn-danger" onClick={notAvailable}>Clear</button></Row>
                </div>
              </div>
            )}

            {category === 'storage' && (
              <div className="settings-panel active">
                <div className="account-section">
                  <h2>Files & Storage</h2>
                  <Row title="Storage used" desc="Weblinks, projects, notes, and account data saved in this browser">
                    <span>{new Blob([localStorage.getItem('ai-dashboard-state-v1') || '']).size} bytes</span>
                  </Row>
                </div>
              </div>
            )}

            {category === 'accessibility' && (
              <div className="settings-panel active">
                <div className="account-section">
                  <h2>Accessibility</h2>
                  <Row title="Font Size">
                    <select value={state.fontSize} onChange={(e) => dispatch({ type: 'SET_FONT_SIZE', size: e.target.value })}>
                      <option value="small">Small</option>
                      <option value="medium">Medium</option>
                      <option value="large">Large</option>
                    </select>
                  </Row>
                  <Row title="Reduce Motion" desc="Minimize animations"><Toggle checked={false} onChange={notAvailable} /></Row>
                </div>
              </div>
            )}

            {category === 'voice' && (
              <div className="settings-panel active">
                <div className="account-section">
                  <h2>Voice & Audio</h2>
                  <Row title="Voice Responses" desc="Read AI replies aloud">
                    <Toggle checked={state.settings.voiceResponse} onChange={(v) => setSetting('voiceResponse', v)} />
                  </Row>
                </div>
              </div>
            )}

            {category === 'about' && (
              <div className="settings-panel active">
                <div className="account-section">
                  <h2>About & Support</h2>
                  <Row title="Version"><span>1.0.0 (React port)</span></Row>
                  <Row title="Contact Support"><button className="settings-btn" onClick={notAvailable}>Contact</button></Row>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
