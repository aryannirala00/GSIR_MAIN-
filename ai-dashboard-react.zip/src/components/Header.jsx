import React from 'react';
import { useAppState, useAppDispatch } from '../context/AppContext.jsx';
import { MAX_TABS } from '../context/reducer.js';

export default function Header() {
  const state = useAppState();
  const dispatch = useAppDispatch();
  const atMax = state.tabs.length >= MAX_TABS;

  const createTab = () => {
    if (atMax) return;
    const n = state.tabs.length + 1;
    dispatch({ type: 'CREATE_TAB', label: `Tab ${n}`, icon: 'fa-comment', tabType: 'chat' });
  };

  const closeTab = (e, id) => {
    e.stopPropagation();
    dispatch({ type: 'CLOSE_TAB', id });
  };

  return (
    <header className="header">
      <div className="header-left">
        <button className="new-tab-btn" id="newTabBtn" title={atMax ? 'Maximum of 15 tabs reached' : 'Create new tab'} disabled={atMax} onClick={createTab}>
          <i className="fas fa-plus"></i>
        </button>
      </div>

      <div className="header-center" id="tabsDisplay">
        {state.tabs.map((tab, i) => (
          <span
            key={tab.id}
            className={`tab-item${tab.id === state.activeTabId && state.page === 'home' ? ' active' : ''}`}
            title={tab.type !== 'chat' ? tab.label : undefined}
            onClick={() => dispatch({ type: 'SWITCH_TAB', id: tab.id })}
          >
            <span className="tab-index">{i}</span>
            <i className={`fas ${tab.icon} tab-icon`}></i>
            {tab.label.length > 18 ? tab.label.slice(0, 18) + '…' : tab.label}
            <i className="fas fa-xmark tab-close" onClick={(e) => closeTab(e, tab.id)}></i>
          </span>
        ))}
      </div>

      <div className="header-right">
        <button
          className="icon-btn has-notification"
          id="notificationBtn"
          title="View notifications"
          onClick={() => dispatch({ type: 'TOGGLE_NOTIFICATION_PANEL' })}
        >
          <i className="fas fa-heart"></i>
          <span className="notification-badge">2</span>
        </button>
        <button className="icon-btn" id="historyBtn" title="View history" onClick={() => dispatch({ type: 'TOGGLE_HISTORY_PANEL' })}>
          <i className="fas fa-bars"></i>
        </button>
      </div>
    </header>
  );
}
