import React, { useEffect, useState } from 'react';
import { useAppState, useAppDispatch } from '../context/AppContext.jsx';

const TOAST_VISIBLE_MS = 3200;

function Toast({ toast }) {
  const dispatch = useAppDispatch();
  const [leaving, setLeaving] = useState(false);

  useEffect(() => {
    const t = setTimeout(() => setLeaving(true), TOAST_VISIBLE_MS);
    return () => clearTimeout(t);
  }, []);

  useEffect(() => {
    if (!leaving) return;
    // Matches the original's animationend-triggered removal — give the
    // toast-leaving CSS transition a moment to actually play before unmount.
    const t = setTimeout(() => dispatch({ type: 'DISMISS_TOAST', id: toast.id }), 220);
    return () => clearTimeout(t);
  }, [leaving, toast.id, dispatch]);

  const icon = toast.kind === 'success' ? 'fa-circle-check' : toast.kind === 'error' ? 'fa-circle-exclamation' : 'fa-circle-info';
  const kindClass = toast.kind === 'success' ? ' toast-success' : toast.kind === 'error' ? ' toast-error' : '';

  return (
    <div
      className={`toast${kindClass}${leaving ? ' toast-leaving' : ''}`}
      role="status"
      onClick={() => setLeaving(true)}
    >
      <i className={`fas ${icon}`}></i>
      <span>{toast.message}</span>
    </div>
  );
}

export default function ToastStack() {
  const state = useAppState();
  return (
    <div className="toast-stack">
      {state.toasts.map((t) => (
        <Toast key={t.id} toast={t} />
      ))}
    </div>
  );
}
