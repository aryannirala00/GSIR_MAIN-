import React, { useState } from 'react';
import { useAppDispatch, useToast } from '../context/AppContext.jsx';

export default function Message({ msg, index }) {
  const dispatch = useAppDispatch();
  const showToast = useToast();
  const [liked, setLiked] = useState(!!msg.liked);

  const copyText = async () => {
    try {
      await navigator.clipboard?.writeText(msg.text);
      showToast('Copied to clipboard', 'success');
    } catch {
      showToast('Could not copy', 'default');
    }
  };

  const shareText = async () => {
    if (navigator.share) {
      try {
        await navigator.share({ text: msg.text });
      } catch {
        // user cancelled the native share sheet — nothing to do
      }
    } else {
      try {
        await navigator.clipboard?.writeText(msg.text);
      } catch {
        /* clipboard unavailable — the toast below still tells the user what to do */
      }
      showToast('Link copied — share it anywhere', 'default');
    }
  };

  const branch = () => {
    dispatch({
      type: 'CREATE_TAB',
      label: 'Branch',
      icon: 'fa-code-branch',
      tabType: 'chat',
      conversation: [{ role: 'ai', text: msg.text, incomplete: false }],
    });
    showToast('New branch created', 'success');
  };

  const continueReply = () => {
    dispatch({ type: 'MARK_TAB_MESSAGE_COMPLETE', index });
    dispatch({
      type: 'ADD_TAB_MESSAGE',
      message: { role: 'ai', text: 'Continuing from the previous response — connect your backend here.', incomplete: false },
    });
  };

  const citation = () => showToast('No sources attached to this response yet', 'default');

  const toggleLike = () => {
    const next = !liked;
    setLiked(next);
    dispatch({ type: 'TOGGLE_TAB_MESSAGE_LIKE', index });
    showToast(next ? 'Thanks for the feedback!' : 'Feedback removed', 'default');
  };

  return (
    <div className={`conv-message ${msg.role}`}>
      <div className="conv-bubble">{msg.text}</div>
      {msg.role === 'ai' && (
        <div className="msg-action-bar">
          <button className="msg-action-btn" data-action="copy" title="Copy" onClick={copyText}>
            <i className="fas fa-copy"></i>
          </button>
          <button className="msg-action-btn" data-action="share" title="Share" onClick={shareText}>
            <i className="fas fa-share-nodes"></i>
          </button>
          <button className="msg-action-btn" data-action="branch" title="Create a new branch" onClick={branch}>
            <i className="fas fa-code-branch"></i>
          </button>
          {msg.incomplete && (
            <button className="msg-action-btn" data-action="continue" title="Continue" onClick={continueReply}>
              <i className="fas fa-forward"></i>
            </button>
          )}
          <button className="msg-action-btn" data-action="citation" title="Show citation" onClick={citation}>
            <i className="fas fa-quote-right"></i>
          </button>
          <button className={`msg-action-btn${liked ? ' active' : ''}`} data-action="like" title="Like (feedback)" onClick={toggleLike}>
            <i className={liked ? 'fas fa-thumbs-up' : 'far fa-thumbs-up'}></i>
          </button>
        </div>
      )}
    </div>
  );
}
