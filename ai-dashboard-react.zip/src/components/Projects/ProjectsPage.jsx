import React, { useRef, useState } from 'react';
import { useAppState, useAppDispatch, useToast } from '../../context/AppContext.jsx';
import { makeId } from '../../utils/time.js';
import ProjectFileItem from './ProjectFileItem.jsx';

const MAX_PROJECTS = 10;
const STEPS = ['Project Introduction', 'Project Goal', 'Additional Information', 'Add Instructions'];

export default function ProjectsPage() {
  const state = useAppState();
  const dispatch = useAppDispatch();
  const showToast = useToast();

  const [screen, setScreen] = useState('select'); // 'select' | 'wizard' | 'detail'
  const [step, setStep] = useState(1);
  const [form, setForm] = useState({ name: '', description: '', goal: '', info: '' });
  const [wizardFiles, setWizardFiles] = useState([]);
  const fileInputRef = useRef(null);
  const detailFileInputRef = useRef(null);

  const [detailTab, setDetailTab] = useState('info');
  const activeProject = state.projects.find((p) => p.id === state.activeProjectId) || null;
  const [detailDraft, setDetailDraft] = useState(null);

  const openWizard = () => {
    setForm({ name: '', description: '', goal: '', info: '' });
    setWizardFiles([]);
    setStep(1);
    setScreen('wizard');
  };

  const nextStep = () => {
    if (step === 1 && !form.name.trim()) {
      showToast('Give the project a name first', 'error');
      return;
    }
    if (step < 4) {
      setStep(step + 1);
      return;
    }
    // finish: create the project (carrying over any files added in step 4) and open it as a new tab
    const newId = makeId('proj');
    dispatch({ type: 'CREATE_PROJECT', project: { ...form, id: newId, files: wizardFiles } });
    dispatch({ type: 'CREATE_TAB', label: form.name, icon: 'fa-folder', tabType: 'chat', projectId: newId });
    showToast('Project created', 'success');
  };

  const backStep = () => {
    if (step === 1) { setScreen('select'); return; }
    setStep(step - 1);
  };

  const addWizardFiles = (fileList) => {
    setWizardFiles((prev) => [...prev, ...Array.from(fileList).map((f) => ({ name: f.name }))]);
  };

  const openDetail = (project) => {
    dispatch({ type: 'OPEN_PROJECT_DETAIL', id: project.id });
    setDetailDraft({ name: project.name, description: project.description, goal: project.goal, info: project.info });
    setDetailTab('info');
    setScreen('detail');
  };

  const saveDetail = () => {
    if (!detailDraft.name.trim()) {
      showToast('Project name can\'t be empty', 'error');
      return;
    }
    dispatch({ type: 'UPDATE_PROJECT_FIELDS', id: activeProject.id, fields: detailDraft });
    showToast('Project saved', 'success');
  };

  const deleteProject = (project) => {
    if (!window.confirm(`Delete "${project.name}"? This can't be undone.`)) return;
    dispatch({ type: 'DELETE_PROJECT', id: project.id });
    showToast('Project deleted', 'default');
  };

  // ---------- SELECT SCREEN ----------
  if (screen === 'select') {
    return (
      <div className="project-page active" id="projectOverlay">
          <div className="project-modal">
            <div className="project-screen project-screen-select active" id="projectScreenSelect">
              <div className="project-select-header">
                <h2>Create Your Project</h2>
                <span className="project-count" id="projectCount">{state.projects.length} / {MAX_PROJECTS}</span>
              </div>
              <p className="project-subtext">Start building something amazing. Choose an option to get started.</p>

              <div className="project-select-grid" id="projectSelectGrid">
                <div
                  className="project-select-card"
                  id="projectNewCard"
                  onClick={() => (state.projects.length < MAX_PROJECTS ? openWizard() : showToast('Maximum of 10 projects reached', 'error'))}
                >
                  <div className="project-select-icon"><i className="fas fa-plus"></i></div>
                  <div className="project-select-text">
                    <strong>New Project</strong>
                    <span>Create a new project</span>
                  </div>
                  <i className="fas fa-chevron-right"></i>
                </div>

                {state.projects.map((p) => (
                  <div className="project-select-card existing" key={p.id} onClick={() => openDetail(p)}>
                    <div className="project-select-icon"><i className="fas fa-folder"></i></div>
                    <div className="project-select-text"><strong>{p.name}</strong></div>
                    <button
                      type="button"
                      className="weblink-remove"
                      title="Delete project"
                      aria-label={`Delete ${p.name}`}
                      onClick={(e) => { e.stopPropagation(); deleteProject(p); }}
                    >
                      <i className="fas fa-xmark"></i>
                    </button>
                    <i className="fas fa-chevron-right"></i>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
    );
  }

  // ---------- WIZARD SCREEN ----------
  if (screen === 'wizard') {
    return (
      <div className="project-page active" id="projectOverlay">
          <div className="project-modal">
            <div className="project-screen project-screen-wizard active" id="projectScreenWizard">
              <div className="project-wizard">
                <div className="project-steps" id="projectSteps">
                  {STEPS.map((label, i) => (
                    <div className={`project-step${step === i + 1 ? ' active' : ''}${step > i + 1 ? ' done' : ''}`} key={label}>
                      <span className="project-step-num">{i + 1}</span>
                      <span>{label}</span>
                    </div>
                  ))}
                </div>

                <div className="project-step-content">
                  {step === 1 && (
                    <div className="project-pane">
                      <label className="shortcut-label" htmlFor="projName">Project name</label>
                      <input type="text" className="shortcut-field" id="projName" placeholder="e.g. AI Dashboard" autoComplete="off"
                        value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} autoFocus />

                      <label className="shortcut-label" htmlFor="projDescription">Short description</label>
                      <textarea className="shortcut-field project-textarea" id="projDescription" placeholder="What is this project about?"
                        value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} />
                    </div>
                  )}
                  {step === 2 && (
                    <div className="project-pane">
                      <label className="shortcut-label" htmlFor="projGoal">Project Goal</label>
                      <textarea className="shortcut-field project-textarea" id="projGoal" placeholder="What are you trying to achieve?"
                        value={form.goal} onChange={(e) => setForm({ ...form, goal: e.target.value })} autoFocus />
                    </div>
                  )}
                  {step === 3 && (
                    <div className="project-pane">
                      <label className="shortcut-label" htmlFor="projInfo">Additional Information</label>
                      <textarea className="shortcut-field project-textarea" id="projInfo" placeholder="Anything else we should know?"
                        value={form.info} onChange={(e) => setForm({ ...form, info: e.target.value })} autoFocus />
                    </div>
                  )}
                  {step === 4 && (
                    <div className="project-pane">
                      <h4 className="project-knowledge-title">Project Knowledge</h4>
                      <div className="project-files" id="projectFiles">
                        {wizardFiles.map((f, i) => (
                          <ProjectFileItem
                            key={i}
                            file={f}
                            onRename={(name) => setWizardFiles((prev) => prev.map((x, idx) => (idx === i ? { ...x, name } : x)))}
                            onDelete={() => setWizardFiles((prev) => prev.filter((_, idx) => idx !== i))}
                            onOpenInTab={() => dispatch({ type: 'CREATE_TAB', label: f.name, icon: 'fa-file', tabType: 'file', payload: { name: f.name } })}
                          />
                        ))}
                      </div>
                      <label className="project-dropzone" id="projectDropzone"
                        onDragOver={(e) => e.preventDefault()}
                        onDrop={(e) => { e.preventDefault(); if (e.dataTransfer?.files?.length) addWizardFiles(e.dataTransfer.files); }}>
                        <i className="fas fa-cloud-arrow-up"></i>
                        <span>Add your own files</span>
                        <small>PDF, images, Word, or any other file type</small>
                        <input type="file" multiple hidden ref={fileInputRef}
                          onChange={(e) => { if (e.target.files.length) addWizardFiles(e.target.files); e.target.value = ''; }} />
                      </label>
                    </div>
                  )}
                </div>
              </div>

              <div className="shortcut-actions project-wizard-actions">
                <button className="shortcut-btn shortcut-btn-cancel" id="projectBackBtn" onClick={backStep}>Back</button>
                <button className="shortcut-btn shortcut-btn-done" id="projectNextBtn" onClick={nextStep}>
                  {step === 4 ? 'Create Project' : 'Next'}
                </button>
              </div>
            </div>
          </div>
        </div>
    );
  }

  // ---------- DETAIL SCREEN ----------
  if (screen === 'detail' && activeProject && detailDraft) {
    return (
      <div className="project-page active" id="projectOverlay">
          <div className="project-modal">
            <div className="project-screen project-screen-detail active" id="projectScreenDetail">
              <div className="project-detail-tabs">
                {['info', 'knowledge', 'history'].map((t) => (
                  <button key={t} className={`project-detail-tab${detailTab === t ? ' active' : ''}`} onClick={() => setDetailTab(t)}>
                    {t === 'info' ? 'Project Info' : t === 'knowledge' ? 'Project Knowledge' : 'Chat History'}
                  </button>
                ))}
              </div>

              {detailTab === 'info' && (
                <div className="project-detail-pane">
                  <label className="shortcut-label" htmlFor="detailName">Project name</label>
                  <input type="text" className="shortcut-field" id="detailName" autoComplete="off"
                    value={detailDraft.name} onChange={(e) => setDetailDraft({ ...detailDraft, name: e.target.value })} />

                  <label className="shortcut-label" htmlFor="detailDescription">1. Project Introduction</label>
                  <textarea className="shortcut-field project-textarea" id="detailDescription" placeholder="Provide a brief introduction about your project."
                    value={detailDraft.description} onChange={(e) => setDetailDraft({ ...detailDraft, description: e.target.value })} />

                  <label className="shortcut-label" htmlFor="detailGoal">2. Project Goal</label>
                  <textarea className="shortcut-field project-textarea" id="detailGoal" placeholder="What do you want to achieve with this project?"
                    value={detailDraft.goal} onChange={(e) => setDetailDraft({ ...detailDraft, goal: e.target.value })} />

                  <label className="shortcut-label" htmlFor="detailInfo">3. Additional Information</label>
                  <textarea className="shortcut-field project-textarea" id="detailInfo" placeholder="Add any extra details that might be helpful."
                    value={detailDraft.info} onChange={(e) => setDetailDraft({ ...detailDraft, info: e.target.value })} />
                </div>
              )}

              {detailTab === 'knowledge' && (
                <div className="project-detail-pane">
                  <h4 className="project-knowledge-title">Project Knowledge</h4>
                  <div className="project-files" id="detailFiles">
                    {activeProject.files.map((f, i) => (
                      <ProjectFileItem
                        key={i}
                        file={f}
                        onRename={(name) => dispatch({ type: 'RENAME_PROJECT_FILE', id: activeProject.id, index: i, name })}
                        onDelete={() => dispatch({ type: 'REMOVE_PROJECT_FILE', id: activeProject.id, index: i })}
                        onOpenInTab={() => dispatch({ type: 'CREATE_TAB', label: f.name, icon: 'fa-file', tabType: 'file', payload: { name: f.name } })}
                      />
                    ))}
                  </div>
                  <label className="project-dropzone" id="detailDropzone"
                    onDragOver={(e) => e.preventDefault()}
                    onDrop={(e) => {
                      e.preventDefault();
                      if (e.dataTransfer?.files?.length) {
                        Array.from(e.dataTransfer.files).forEach((f) => dispatch({ type: 'ADD_PROJECT_FILE', id: activeProject.id, file: { name: f.name } }));
                      }
                    }}>
                    <i className="fas fa-cloud-arrow-up"></i>
                    <span>Add your own files</span>
                    <small>PDF, images, Word, or any other file type</small>
                    <input type="file" multiple hidden ref={detailFileInputRef}
                      onChange={(e) => {
                        if (e.target.files.length) {
                          Array.from(e.target.files).forEach((f) => dispatch({ type: 'ADD_PROJECT_FILE', id: activeProject.id, file: { name: f.name } }));
                        }
                        e.target.value = '';
                      }} />
                  </label>
                </div>
              )}

              {detailTab === 'history' && (
                <div className="project-detail-pane">
                  <h4 className="project-knowledge-title">Chat History</h4>
                  <div className="panel-content project-history-list" id="detailHistoryList">
                    {activeProject.chatHistory.length === 0 && <div className="project-history-empty">No chats in this project yet.</div>}
                    {activeProject.chatHistory.map((entry, i) => (
                      <div className="project-history-item" key={i}><i className="fas fa-message"></i><span>{entry}</span></div>
                    ))}
                  </div>
                </div>
              )}

              <div className="shortcut-actions project-wizard-actions">
                <button className="shortcut-btn shortcut-btn-cancel" id="detailOpenBtn" onClick={() => {
                  dispatch({ type: 'CREATE_TAB', label: activeProject.name, icon: 'fa-folder', tabType: 'chat', projectId: activeProject.id });
                }}>Go to Search</button>
                <button className="shortcut-btn shortcut-btn-done" id="detailSaveBtn" onClick={saveDetail}>Save Changes</button>
              </div>
            </div>
          </div>
        </div>
    );
  }

  return null;
}
