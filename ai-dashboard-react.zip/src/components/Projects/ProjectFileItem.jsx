import React, { useState } from 'react';
import { getIconForName } from '../../utils/icons.js';

export default function ProjectFileItem({ file, onRename, onDelete, onOpenInTab }) {
  const [menuOpen, setMenuOpen] = useState(false);
  const [renaming, setRenaming] = useState(false);
  const [draft, setDraft] = useState(file.name);

  const submitRename = () => {
    const v = draft.trim();
    if (v) onRename(v);
    setRenaming(false);
  };

  return (
    <div className="project-file-item">
      <i className={`fas ${getIconForName(file.name)} file-type-icon`}></i>
      {renaming ? (
        <input
          className="shortcut-field"
          autoFocus
          value={draft}
          onChange={(e) => setDraft(e.target.value)}
          onKeyDown={(e) => { if (e.key === 'Enter') submitRename(); if (e.key === 'Escape') setRenaming(false); }}
          onBlur={submitRename}
        />
      ) : (
        <span>{file.name}</span>
      )}
      <button type="button" className="item-menu-btn project-file-menu-btn" title="More options" aria-label="More options" onClick={() => setMenuOpen((v) => !v)}>
        <i className="fas fa-ellipsis-vertical"></i>
      </button>
      {menuOpen && (
        <div className="item-menu-dropdown open">
          <button type="button" onClick={() => { setMenuOpen(false); setRenaming(true); }}><i className="fas fa-pen"></i> Rename</button>
          <button type="button" onClick={() => { setMenuOpen(false); onOpenInTab(); }}><i className="fas fa-up-right-from-square"></i> Open in tab</button>
          <button type="button" className="danger" onClick={() => { setMenuOpen(false); onDelete(); }}><i className="fas fa-trash"></i> Delete</button>
        </div>
      )}
    </div>
  );
}
