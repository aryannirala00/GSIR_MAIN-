import React, { useEffect, useMemo, useRef, useState } from 'react';
import { useAppState, useAppDispatch, useToast } from '../../context/AppContext.jsx';
import { formatRelativeTime } from '../../utils/time.js';
import NoteCard from './NoteCard.jsx';

const BATCH_SIZE = 6;

export default function NotesPage() {
  const state = useAppState();
  const dispatch = useAppDispatch();
  const showToast = useToast();

  const sortedNotes = useMemo(() => state.notes.slice().sort((a, b) => b.updatedAt - a.updatedAt), [state.notes]);
  const [renderedCount, setRenderedCount] = useState(BATCH_SIZE);
  const sentinelRef = useRef(null);

  useEffect(() => {
    const el = sentinelRef.current;
    if (!el) return;
    const observer = new IntersectionObserver((entries) => {
      if (entries[0].isIntersecting) {
        setRenderedCount((c) => Math.min(c + BATCH_SIZE, sortedNotes.length));
      }
    });
    observer.observe(el);
    return () => observer.disconnect();
  }, [sortedNotes.length]);

  const visibleNotes = sortedNotes.slice(0, renderedCount);

  // ---- Editor state (title/content are local drafts, committed on save) ----
  const editingNote = state.activeNoteId ? state.notes.find((n) => n.id === state.activeNoteId) : null;
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [titleInvalid, setTitleInvalid] = useState(false);

  useEffect(() => {
    if (state.notesEditorOpen) {
      setTitle(editingNote ? editingNote.title : '');
      setContent(editingNote ? editingNote.content : '');
      setTitleInvalid(false);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [state.notesEditorOpen, state.activeNoteId]);

  const openNew = () => dispatch({ type: 'OPEN_NOTE_EDITOR', id: null });
  const openExisting = (id) => dispatch({ type: 'OPEN_NOTE_EDITOR', id });

  const back = () => {
    // Matches the original: an empty note (no title, no content) is
    // discarded rather than left behind as a blank card, whether it's a
    // brand-new note or an existing one someone cleared out.
    if (title.trim() || content.trim()) {
      dispatch({ type: 'SAVE_NOTE', id: state.activeNoteId, title, content });
    } else if (state.activeNoteId) {
      dispatch({ type: 'DELETE_NOTE', id: state.activeNoteId });
    } else {
      dispatch({ type: 'CLOSE_NOTE_EDITOR' });
    }
  };

  const save = () => {
    if (!title.trim()) {
      setTitleInvalid(true);
      showToast('Please add a title before saving', 'error');
      return;
    }
    dispatch({ type: 'SAVE_NOTE', id: state.activeNoteId, title, content });
    showToast('Note saved', 'success');
  };

  const deleteNote = () => {
    if (!state.activeNoteId) return;
    if (!window.confirm('Delete this note? This can\'t be undone.')) return;
    dispatch({ type: 'DELETE_NOTE', id: state.activeNoteId });
    showToast('Note deleted', 'default');
  };

  const openInTab = (note) => {
    dispatch({ type: 'CREATE_TAB', label: note.title || 'Untitled note', icon: 'fa-note-sticky', tabType: 'note', payload: { title: note.title, text: note.content } });
  };

  if (state.notesEditorOpen) {
    return (
      <div className="notes-page active" id="notesPage">
        <div className="notes-editor-view show">
          <div className="account-section notes-editor-card">
            <button className="notes-back-btn" type="button" onClick={back}>
              <i className="fas fa-arrow-left"></i> Back to notes
            </button>

            <div className="account-field full">
              <label htmlFor="noteTitleInput">Title <span className="required-mark" aria-hidden="true">*</span></label>
              <input
                type="text"
                id="noteTitleInput"
                className={titleInvalid ? 'field-invalid' : ''}
                placeholder="Note title"
                maxLength={120}
                required
                autoFocus
                value={title}
                onChange={(e) => { setTitle(e.target.value); setTitleInvalid(false); }}
              />
            </div>
            <div className="account-field full">
              <label htmlFor="noteContentInput">Note</label>
              <textarea id="noteContentInput" placeholder="Write anything…" rows={10} value={content} onChange={(e) => setContent(e.target.value)} />
            </div>
            <p className="notes-editor-meta">{editingNote ? `Last edited ${formatRelativeTime(editingNote.updatedAt)}` : ''}</p>
          </div>

          <div className="account-save-bar notes-save-bar">
            {editingNote && (
              <button className="settings-btn settings-btn-danger" id="noteDeleteBtn" type="button" onClick={deleteNote}>
                Delete
              </button>
            )}
            <button className="account-save-btn" id="noteSaveBtn" type="button" onClick={save}>Save Note</button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="notes-page active" id="notesPage">
      <div className="account-page-header notes-page-header">
        <div>
          <h1>Notes</h1>
          <p>Quick personal notes — separate from your lab &amp; account records.</p>
        </div>
        <button className="notes-new-btn" type="button" onClick={openNew}>
          <i className="fas fa-plus"></i> New Note
        </button>
      </div>

      <div className="notes-list-view" id="notesListView">
        <div className="notes-grid" id="notesGrid">
          {visibleNotes.map((note) => (
            <NoteCard
              key={note.id}
              note={note}
              onOpen={() => openExisting(note.id)}
              onDelete={() => {
                if (!window.confirm('Delete this note? This can\'t be undone.')) return;
                dispatch({ type: 'DELETE_NOTE', id: note.id });
                showToast('Note deleted', 'default');
              }}
              onRename={(newTitle) => dispatch({ type: 'RENAME_NOTE', id: note.id, title: newTitle })}
              onOpenInTab={() => openInTab(note)}
            />
          ))}
        </div>

        {!sortedNotes.length && (
          <div className="notes-empty-state" id="notesEmptyState">
            <i className="fas fa-note-sticky"></i>
            <p>No notes yet</p>
            <span>Click "New Note" to write your first one.</span>
          </div>
        )}

        <div className="notes-lazy-sentinel" id="notesLazySentinel" aria-hidden="true" ref={sentinelRef}></div>
      </div>
    </div>
  );
}
