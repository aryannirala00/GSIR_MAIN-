import React, { useState } from 'react';
import { formatRelativeTime } from '../../utils/time.js';

export default function NoteCard({ note, onOpen, onDelete, onRename, onOpenInTab }) {
  const [menuOpen, setMenuOpen] = useState(false);
  const [renaming, setRenaming] = useState(false);
  const [draftTitle, setDraftTitle] = useState(note.title);

  const title = note.title.trim() || 'Untitled note';
  const preview = note.content.trim() || 'No additional text';

  const submitRename = () => {
    const t = draftTitle.trim();
    if (t) onRename(t);
    setRenaming(false);
  };

  return (
    <div className="notes-card" tabIndex={0} role="button" onClick={() => !menuOpen && !renaming && onOpen()}>
      <button
        type="button"
        className="item-menu-btn notes-card-menu-btn"
        title="More options"
        aria-label="More options"
        onClick={(e) => { e.stopPropagation(); setMenuOpen((v) => !v); }}
      >
        <i className="fas fa-ellipsis-vertical"></i>
      </button>
      {menuOpen && (
        <div className="item-menu-dropdown open" onClick={(e) => e.stopPropagation()}>
          <button type="button" onClick={() => { setMenuOpen(false); setRenaming(true); setDraftTitle(note.title); }}>
            <i className="fas fa-pen"></i> Rename
          </button>
          <button type="button" onClick={() => { setMenuOpen(false); onOpenInTab(); }}>
            <i className="fas fa-up-right-from-square"></i> Open in tab
          </button>
          <button type="button" className="danger" onClick={() => { setMenuOpen(false); onDelete(); }}>
            <i className="fas fa-trash"></i> Delete
          </button>
        </div>
      )}

      {renaming ? (
        <input
          className="shortcut-field"
          autoFocus
          value={draftTitle}
          onClick={(e) => e.stopPropagation()}
          onChange={(e) => setDraftTitle(e.target.value)}
          onKeyDown={(e) => { if (e.key === 'Enter') submitRename(); if (e.key === 'Escape') setRenaming(false); }}
          onBlur={submitRename}
        />
      ) : (
        <h3>{title}</h3>
      )}
      <p>{preview}</p>
      <time>{formatRelativeTime(note.updatedAt)}</time>
    </div>
  );
}
