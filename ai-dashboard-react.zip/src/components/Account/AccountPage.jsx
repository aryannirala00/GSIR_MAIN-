import React, { useRef, useState } from 'react';
import { useAppState, useAppDispatch, useToast } from '../../context/AppContext.jsx';
import { isValidEmail } from '../../utils/time.js';
import StarRatings from './StarRatings.jsx';
import AvatarCropModal from './AvatarCropModal.jsx';
import CroppedAvatar from './CroppedAvatar.jsx';

const RESEARCH_INTERESTS = ['Organic Chemistry', 'Biochemistry', 'Materials Science', 'Microbiology', 'Pharmacology', 'Environmental Science', 'Nanotechnology', 'Genetics'];
const TABS = [
  { key: 'profile', label: 'Profile', icon: 'fa-user' },
  { key: 'contact', label: 'Contact & Work', icon: 'fa-address-book' },
  { key: 'lab', label: 'Laboratory', icon: 'fa-flask' },
  { key: 'supplier', label: 'Supplier', icon: 'fa-truck-field' },
];

function Field({ label, required, children }) {
  return (
    <div className="account-field">
      <label>{label} {required && <span className="required-mark" aria-hidden="true">*</span>}</label>
      {children}
    </div>
  );
}

export default function AccountPage() {
  const state = useAppState();
  const dispatch = useAppDispatch();
  const showToast = useToast();
  const [tab, setTab] = useState('profile');
  const [avatarModalOpen, setAvatarModalOpen] = useState(false);
  const [equipmentDraft, setEquipmentDraft] = useState('');
  const reviewInputRef = useRef(null);

  const acc = state.account;
  const locked = acc.locked;

  const update = (section, fields) => dispatch({ type: 'UPDATE_ACCOUNT_SECTION', section, fields });

  const save = () => {
    if (!acc.profile.name.trim()) { showToast('Please fill in the required fields', 'error'); setTab('profile'); return; }
    if (!isValidEmail(acc.contactWork.email)) { showToast('Please fill in the required fields', 'error'); setTab('contact'); return; }
    dispatch({ type: 'SAVE_ACCOUNT' });
    showToast('Account saved', 'success');
  };

  const addEquipment = () => {
    const v = equipmentDraft.trim();
    if (!v) return;
    dispatch({ type: 'ADD_EQUIPMENT', name: v });
    setEquipmentDraft('');
  };

  const addReviewImages = (fileList) => {
    Array.from(fileList).forEach((f) => dispatch({ type: 'ADD_REVIEW_IMAGE', name: f.name }));
  };

  return (
    <>
      <div className="account-page active" id="accountPage">
        <div className="account-page-header">
          <h1>Account</h1>
          <p>Manage your profile, lab, and supplier information.</p>
        </div>

        <div className="settings-layout">
          <div className="settings-nav" id="accountNav">
            {TABS.map((t) => (
              <div key={t.key} className={`settings-nav-item${tab === t.key ? ' active' : ''}`} onClick={() => setTab(t.key)}>
                <i className={`fas ${t.icon}`}></i>{t.label}
              </div>
            ))}
          </div>

          <div className="settings-panels" id="accountPanels">
            {/* ---------------- PROFILE ---------------- */}
            {tab === 'profile' && (
              <div className="settings-panel active">
                <div className="account-section">
                  <h2>Profile</h2>
                  <p className="section-sub">Your public profile details.</p>

                  <div className="profile-pic-row">
                    <div className="profile-pic-preview" id="profilePicPreview">
                      {acc.avatarDataUrl ? <CroppedAvatar dataUrl={acc.avatarDataUrl} crop={acc.avatarCrop} size={84} /> : 'AN'}
                    </div>
                    <div>
                      <button className="profile-pic-edit-btn" id="profilePicEditBtn" disabled={locked} onClick={() => setAvatarModalOpen(true)}>Edit Picture</button>
                    </div>
                  </div>

                  <div className="account-grid">
                    <Field label="Name" required>
                      <input type="text" placeholder="Full name" required disabled={locked}
                        value={acc.profile.name} onChange={(e) => update('profile', { name: e.target.value })} />
                    </Field>
                    <Field label="Age">
                      <input type="number" min="0" placeholder="Age" disabled={locked}
                        value={acc.profile.age} onChange={(e) => update('profile', { age: e.target.value })} />
                    </Field>
                    <Field label="Gender">
                      <select disabled={locked} value={acc.profile.gender} onChange={(e) => update('profile', { gender: e.target.value })}>
                        <option value="">Select</option>
                        <option>Male</option><option>Female</option><option>Non-binary</option><option>Prefer not to say</option>
                      </select>
                    </Field>
                    <Field label="Date of Birth">
                      <input type="date" disabled={locked} value={acc.profile.dob} onChange={(e) => update('profile', { dob: e.target.value })} />
                    </Field>
                    <div className="account-field full">
                      <label>Research Interests</label>
                      <div className="chip-select" id="researchInterestChips">
                        {RESEARCH_INTERESTS.map((v) => (
                          <span
                            key={v}
                            className={`chip${acc.profile.researchInterests.includes(v) ? ' selected' : ''}`}
                            onClick={() => !locked && dispatch({ type: 'TOGGLE_RESEARCH_INTEREST', value: v })}
                          >{v}</span>
                        ))}
                      </div>
                    </div>
                    <div className="account-field full">
                      <label>Bio</label>
                      <textarea placeholder="Tell others about yourself" disabled={locked}
                        value={acc.profile.bio} onChange={(e) => update('profile', { bio: e.target.value })} />
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* ---------------- CONTACT & WORK ---------------- */}
            {tab === 'contact' && (
              <div className="settings-panel active">
                <div className="account-section">
                  <h2>Contact Information</h2>
                  <div className="account-grid">
                    <Field label="Mobile"><input type="tel" placeholder="+1 555 000 0000" disabled={locked} value={acc.contactWork.mobile} onChange={(e) => update('contactWork', { mobile: e.target.value })} /></Field>
                    <Field label="Email" required><input type="email" placeholder="you@example.com" required disabled={locked} value={acc.contactWork.email} onChange={(e) => update('contactWork', { email: e.target.value })} /></Field>
                    <Field label="Country"><input type="text" disabled={locked} value={acc.contactWork.country} onChange={(e) => update('contactWork', { country: e.target.value })} /></Field>
                    <Field label="State"><input type="text" disabled={locked} value={acc.contactWork.state} onChange={(e) => update('contactWork', { state: e.target.value })} /></Field>
                    <Field label="City"><input type="text" disabled={locked} value={acc.contactWork.city} onChange={(e) => update('contactWork', { city: e.target.value })} /></Field>
                  </div>
                </div>

                <div className="account-section">
                  <h2>Work Information</h2>
                  <div className="account-grid">
                    <Field label="Organisation"><input type="text" disabled={locked} value={acc.contactWork.organization} onChange={(e) => update('contactWork', { organization: e.target.value })} /></Field>
                    <Field label="Department"><input type="text" disabled={locked} value={acc.contactWork.department} onChange={(e) => update('contactWork', { department: e.target.value })} /></Field>
                    <Field label="Designation"><input type="text" disabled={locked} value={acc.contactWork.designation} onChange={(e) => update('contactWork', { designation: e.target.value })} /></Field>
                    <Field label="Employee / Student ID"><input type="text" disabled={locked} value={acc.contactWork.workId} onChange={(e) => update('contactWork', { workId: e.target.value })} /></Field>
                    <Field label="Experience (years)"><input type="number" min="0" disabled={locked} value={acc.contactWork.experience} onChange={(e) => update('contactWork', { experience: e.target.value })} /></Field>
                  </div>

                  <div className="account-field full" style={{ marginTop: 16 }}>
                    <label>Licensed Chemicals</label>
                    <div className="radio-pill-group">
                      <label className="radio-pill"><input type="radio" name="licensedChemicals" checked={!!acc.contactWork.licensedChemicals} disabled={locked} onChange={() => update('contactWork', { licensedChemicals: true })} /> Yes</label>
                      <label className="radio-pill"><input type="radio" name="licensedChemicals" checked={!acc.contactWork.licensedChemicals} disabled={locked} onChange={() => update('contactWork', { licensedChemicals: false })} /> No</label>
                    </div>
                    {acc.contactWork.licensedChemicals && (
                      <div className="conditional-block open">
                        <div className="account-grid">
                          <Field label="License Number"><input type="text" disabled={locked} value={acc.laboratory.licenseNumber} onChange={(e) => update('laboratory', { licenseNumber: e.target.value })} /></Field>
                          <Field label="Expiry Date"><input type="date" disabled={locked} value={acc.laboratory.licenseExpiry} onChange={(e) => update('laboratory', { licenseExpiry: e.target.value })} /></Field>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            )}

            {/* ---------------- LABORATORY ---------------- */}
            {tab === 'lab' && (
              <div className="settings-panel active">
                <div className="account-section">
                  <h2>Laboratory Information</h2>
                  <div className="account-grid">
                    <Field label="Laboratory Name"><input type="text" disabled={locked} value={acc.laboratory.labName} onChange={(e) => update('laboratory', { labName: e.target.value })} /></Field>
                    <Field label="Organisation Name"><input type="text" disabled={locked} value={acc.laboratory.labOrg} onChange={(e) => update('laboratory', { labOrg: e.target.value })} /></Field>
                    <div className="account-field full"><label>Address</label><input type="text" disabled={locked} value={acc.laboratory.address} onChange={(e) => update('laboratory', { address: e.target.value })} /></div>
                    <div className="account-field full"><label>Google Maps Location</label><input type="url" placeholder="https://maps.google.com/..." disabled={locked} value={acc.laboratory.mapsUrl} onChange={(e) => update('laboratory', { mapsUrl: e.target.value })} /></div>
                    <div className="account-field full">
                      <label>Working Days</label>
                      <div className="checkbox-list" id="labWorkingDays">
                        {['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'].map((d) => {
                          const days = acc.laboratory.workingDays ? acc.laboratory.workingDays.split(',') : [];
                          const checked = days.includes(d);
                          return (
                            <label key={d}>
                              <input type="checkbox" disabled={locked} checked={checked} onChange={() => {
                                const next = checked ? days.filter((x) => x !== d) : [...days, d];
                                update('laboratory', { workingDays: next.join(',') });
                              }} />{d}
                            </label>
                          );
                        })}
                      </div>
                    </div>
                    <Field label="Opening Time"><input type="time" disabled={locked} value={acc.laboratory.openTime} onChange={(e) => update('laboratory', { openTime: e.target.value })} /></Field>
                    <Field label="Closing Time"><input type="time" disabled={locked} value={acc.laboratory.closeTime} onChange={(e) => update('laboratory', { closeTime: e.target.value })} /></Field>
                    <div className="account-field full">
                      <label>Laboratory Type</label>
                      <select disabled={locked} value={acc.laboratory.labType} onChange={(e) => update('laboratory', { labType: e.target.value })}>
                        <option value="">Select</option>
                        {['School', 'College', 'Research', 'Industrial', 'Government', 'Private', 'Startup', 'Other'].map((o) => <option key={o}>{o}</option>)}
                      </select>
                    </div>
                  </div>

                  <div className="account-field full" style={{ marginTop: 16 }}>
                    <label style={{ fontSize: 13, fontWeight: 600, color: 'var(--text-gray)' }}>Equipment List</label>
                    <div className="tag-list" id="equipmentTagList">
                      {acc.laboratory.equipmentList.map((name, i) => (
                        <span className="tag-pill" key={i}>
                          {name}
                          <button type="button" title="Remove" aria-label={`Remove ${name}`} disabled={locked} onClick={() => dispatch({ type: 'REMOVE_EQUIPMENT', index: i })}>
                            <i className="fas fa-xmark"></i>
                          </button>
                        </span>
                      ))}
                    </div>
                    <div className="add-tag-row">
                      <input type="text" id="equipmentInput" placeholder="e.g. Mass Spectrometer" disabled={locked}
                        value={equipmentDraft} onChange={(e) => setEquipmentDraft(e.target.value)}
                        onKeyDown={(e) => { if (e.key === 'Enter') { e.preventDefault(); addEquipment(); } }} />
                      <button type="button" id="equipmentAddBtn" disabled={locked} onClick={addEquipment}>Add</button>
                    </div>
                  </div>
                </div>

                <div className="account-section">
                  <h2>Laboratory Rating</h2>
                  <StarRatings ratings={acc.laboratory.ratings} onChange={(cat, val) => !locked && dispatch({ type: 'SET_LAB_RATING', category: cat, value: val })} />
                </div>

                <div className="account-section">
                  <h2>Laboratory Review</h2>
                  <div className="account-grid">
                    <div className="account-field full"><label>Review Title</label><input type="text" disabled={locked} value={acc.laboratory.reviewTitle} onChange={(e) => update('laboratory', { reviewTitle: e.target.value })} /></div>
                    <div className="account-field full"><label>Review Description</label><textarea disabled={locked} value={acc.laboratory.reviewDescription} onChange={(e) => update('laboratory', { reviewDescription: e.target.value })} /></div>
                    <div className="account-field full">
                      <label>Upload Images</label>
                      <label className="upload-images-drop" id="reviewImagesDrop"
                        onDragOver={(e) => e.preventDefault()}
                        onDrop={(e) => { e.preventDefault(); if (!locked && e.dataTransfer?.files?.length) addReviewImages(e.dataTransfer.files); }}>
                        <i className="fas fa-cloud-arrow-up"></i>
                        <div>Click or drag images here</div>
                        <input type="file" accept="image/*" multiple hidden ref={reviewInputRef} disabled={locked}
                          onChange={(e) => { if (e.target.files.length) addReviewImages(e.target.files); e.target.value = ''; }} />
                      </label>
                      <div className="tag-list" id="reviewImagesList">
                        {acc.laboratory.reviewImages.map((name, i) => (
                          <span className="tag-pill" key={i}>
                            <i className="fas fa-image"></i> {name}
                            <button type="button" title="Remove" aria-label={`Remove ${name}`} disabled={locked} onClick={() => dispatch({ type: 'REMOVE_REVIEW_IMAGE', index: i })}>
                              <i className="fas fa-xmark"></i>
                            </button>
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* ---------------- SUPPLIER ---------------- */}
            {tab === 'supplier' && (
              <div className="settings-panel active">
                <div className="account-section">
                  <h2>Supplier</h2>
                  <p className="section-sub">Register as a supplier — this listing also appears in the web store's Supplier section.</p>
                  <div className="radio-pill-group">
                    <label className="radio-pill"><input type="radio" name="isSupplier" disabled={locked} checked={!!acc.supplier.isSupplier} onChange={() => update('supplier', { isSupplier: true })} /> Yes</label>
                    <label className="radio-pill"><input type="radio" name="isSupplier" disabled={locked} checked={!acc.supplier.isSupplier} onChange={() => update('supplier', { isSupplier: false })} /> No</label>
                  </div>
                  {acc.supplier.isSupplier && (
                    <div className="conditional-block open">
                      <div className="account-grid">
                        <Field label="Company Name"><input type="text" disabled={locked} value={acc.supplier.company} onChange={(e) => update('supplier', { company: e.target.value })} /></Field>
                        <Field label="Website"><input type="url" placeholder="https://" disabled={locked} value={acc.supplier.website} onChange={(e) => update('supplier', { website: e.target.value })} /></Field>
                        <div className="account-field full"><label>Location of your company</label><input type="text" disabled={locked} value={acc.supplier.location} onChange={(e) => update('supplier', { location: e.target.value })} /></div>
                        <Field label="Contact Number"><input type="tel" disabled={locked} value={acc.supplier.contact} onChange={(e) => update('supplier', { contact: e.target.value })} /></Field>
                        <div className="account-field full"><label>Description</label><textarea disabled={locked} value={acc.supplier.description} onChange={(e) => update('supplier', { description: e.target.value })} /></div>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>
        </div>

        <div className="account-save-bar">
          {locked ? (
            <button className="account-save-btn" id="accountEditBtn" onClick={() => dispatch({ type: 'UNLOCK_ACCOUNT' })}>Edit</button>
          ) : (
            <button className="account-save-btn" id="accountSaveBtn" onClick={save}>Save Changes</button>
          )}
        </div>
      </div>

      <AvatarCropModal
        open={avatarModalOpen}
        onClose={() => setAvatarModalOpen(false)}
        onSave={({ dataUrl, crop }) => dispatch({ type: 'SET_AVATAR', dataUrl, crop })}
      />
    </>
  );
}
