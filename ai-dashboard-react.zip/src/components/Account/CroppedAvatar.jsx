import React from 'react';

// Reproduces applyAvatarCrop(el, size) from the original: the same
// oversized image, repositioned proportionally for whatever pixel size
// this particular avatar spot needs (36px in the sidebar, 84px in Account).
export default function CroppedAvatar({ dataUrl, crop, size }) {
  if (!dataUrl || !crop) return null;
  const ratio = size / crop.vp;
  return (
    <img
      src={dataUrl}
      alt="Profile"
      style={{
        position: 'absolute',
        width: crop.dispW * ratio,
        height: crop.dispH * ratio,
        left: crop.left * ratio,
        top: crop.top * ratio,
        maxWidth: 'none',
        borderRadius: '50%',
      }}
    />
  );
}
