import React from 'react';

const CATEGORIES = ['Cleanliness', 'Safety', 'Equipment', 'Staff'];

export default function StarRatings({ ratings, onChange }) {
  return (
    <div id="labRatingList">
      {CATEGORIES.map((cat) => (
        <div className="rating-row" key={cat}>
          <span className="rating-label">{cat}</span>
          <span className="star-group">
            {[1, 2, 3, 4, 5].map((n) => (
              <i
                key={n}
                className={`fas fa-star${n <= (ratings[cat] || 0) ? ' filled' : ''}`}
                onClick={() => onChange(cat, n)}
              ></i>
            ))}
          </span>
        </div>
      ))}
    </div>
  );
}
