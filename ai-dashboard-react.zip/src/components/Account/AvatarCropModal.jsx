import React, { useRef, useState } from 'react';
import { useToast } from '../../context/AppContext.jsx';

const VP = 220; // viewport diameter, px

export default function AvatarCropModal({ open, onClose, onSave }) {
  const showToast = useToast();
  const imgRef = useRef(null);
  const [srcUrl, setSrcUrl] = useState(null);
  const [natural, setNatural] = useState({ w: 0, h: 0 });
  const [state, setState] = useState({ baseScale: 1, dispW: 0, dispH: 0, left: 0, top: 0 });
  const dragRef = useRef(null);
  const fileInputRef = useRef(null);

  const clamp = (s) => {
    const minLeft = Math.min(0, VP - s.dispW);
    const minTop = Math.min(0, VP - s.dispH);
    return { ...s, left: Math.max(minLeft, Math.min(0, s.left)), top: Math.max(minTop, Math.min(0, s.top)) };
  };

  const pickFile = () => fileInputRef.current?.click();

  const onFileChange = (e) => {
    const file = e.target.files[0];
    e.target.value = '';
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (ev) => setSrcUrl(ev.target.result);
    reader.onerror = () => showToast('Could not read that file — try a different image', 'error');
    reader.readAsDataURL(file);
  };

  const onImgLoad = () => {
    const w = imgRef.current.naturalWidth;
    const h = imgRef.current.naturalHeight;
    if (!w || !h) {
      showToast('That file could not be loaded as an image', 'error');
      setSrcUrl(null);
      return;
    }
    setNatural({ w, h });
    const baseScale = Math.max(VP / w, VP / h);
    const dispW = w * baseScale;
    const dispH = h * baseScale;
    setState({ baseScale, dispW, dispH, left: (VP - dispW) / 2, top: (VP - dispH) / 2 });
  };

  const setZoom = (zoomFactor) => {
    setState((s) => {
      const cx = s.left + s.dispW / 2;
      const cy = s.top + s.dispH / 2;
      const newScale = s.baseScale * zoomFactor;
      const dispW = natural.w * newScale;
      const dispH = natural.h * newScale;
      return clamp({ ...s, dispW, dispH, left: cx - dispW / 2, top: cy - dispH / 2 });
    });
  };

  const startDrag = (x, y) => { dragRef.current = { x, y, left: state.left, top: state.top }; };
  const moveDrag = (x, y) => {
    if (!dragRef.current) return;
    const d = dragRef.current;
    setState((s) => clamp({ ...s, left: d.left + (x - d.x), top: d.top + (y - d.y) }));
  };
  const endDrag = () => { dragRef.current = null; };

  const save = () => {
    onSave({ dataUrl: srcUrl, crop: { ...state, vp: VP } });
    setSrcUrl(null);
    onClose();
  };

  const cancel = () => {
    setSrcUrl(null);
    onClose();
  };

  if (!open) return null;

  return (
    <div className="avatar-adjust-overlay active" id="avatarAdjustOverlay">
      <div className="avatar-adjust-modal">
        <h3>Adjust Picture</h3>

        {!srcUrl ? (
          <div style={{ padding: '30px 0', textAlign: 'center' }}>
            <button className="profile-pic-edit-btn" onClick={pickFile}>Choose a photo…</button>
            <input type="file" accept="image/*" hidden ref={fileInputRef} onChange={onFileChange} />
          </div>
        ) : (
          <>
            <div
              className="avatar-adjust-viewport"
              id="avatarAdjustViewport"
              onMouseDown={(e) => startDrag(e.clientX, e.clientY)}
              onMouseMove={(e) => moveDrag(e.clientX, e.clientY)}
              onMouseUp={endDrag}
              onMouseLeave={endDrag}
              onTouchStart={(e) => { e.preventDefault(); const t = e.touches[0]; startDrag(t.clientX, t.clientY); }}
              onTouchMove={(e) => { e.preventDefault(); const t = e.touches[0]; moveDrag(t.clientX, t.clientY); }}
              onTouchEnd={endDrag}
            >
              <img
                ref={imgRef}
                src={srcUrl}
                alt=""
                onLoad={onImgLoad}
                style={{ width: state.dispW, height: state.dispH, left: state.left, top: state.top }}
              />
            </div>
            <div className="avatar-adjust-controls">
              <i className="fas fa-magnifying-glass-minus"></i>
              <input type="range" id="avatarZoomSlider" min={100} max={250} defaultValue={100}
                onChange={(e) => setZoom(Number(e.target.value) / 100)} />
              <i className="fas fa-magnifying-glass-plus"></i>
            </div>
            <p className="avatar-adjust-hint">Drag to reposition · use the slider to zoom</p>
          </>
        )}

        <div className="avatar-adjust-actions">
          <button className="avatar-adjust-cancel" id="avatarAdjustCancelBtn" onClick={cancel}>Cancel</button>
          <button className="avatar-adjust-save" id="avatarAdjustSaveBtn" disabled={!srcUrl} onClick={save}>Save</button>
        </div>
      </div>
    </div>
  );
}
