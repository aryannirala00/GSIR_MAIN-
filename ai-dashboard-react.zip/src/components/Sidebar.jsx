import React, { useCallback, useRef, useState } from 'react';
import { useAppState, useAppDispatch } from '../context/AppContext.jsx';
import CroppedAvatar from './Account/CroppedAvatar.jsx';

const supportsHover = typeof window !== 'undefined' && window.matchMedia
  ? window.matchMedia('(hover: hover) and (pointer: fine)').matches
  : true;

export default function Sidebar() {
  const state = useAppState();
  const dispatch = useAppDispatch();
  const [expanded, setExpanded] = useState(false);
  const shrinkTimer = useRef(null);

  const popOut = useCallback(() => {
    clearTimeout(shrinkTimer.current);
    setExpanded(true);
  }, []);

  const shrinkSoon = useCallback((delay = 250) => {
    clearTimeout(shrinkTimer.current);
    shrinkTimer.current = setTimeout(() => setExpanded(false), delay);
  }, []);

  const handleMouseEnter = () => {
    if (supportsHover) popOut();
  };
  const handleMouseLeave = () => {
    if (supportsHover) shrinkSoon(250);
  };

  const goTo = (page) => {
    popOut();
    if (page === 'notes' && state.page === 'notes') {
      // Toggling Notes again while already open snaps back to whatever
      // view you were on before — same fast in/out behavior as the
      // original's pinned-tab-turned-sidebar-item.
      dispatch({ type: 'CLOSE_NOTES_TO_PREVIOUS' });
    } else {
      dispatch({ type: 'SET_PAGE', page });
    }
    if (supportsHover) shrinkSoon(500);
  };

  const items = [
    { key: 'home', label: 'Home page', icon: 'fa-home' },
    { key: 'weblink', label: 'Web link', icon: 'fa-link' },
    { key: 'projects', label: 'Projects', icon: 'fa-envelope' },
    { key: 'notes', label: 'Notes', icon: 'fa-file-alt' },
    { key: 'accounts', label: 'Accounts', avatar: true },
    { key: 'settings', label: 'Settings', icon: 'fa-cog' },
  ];

  return (
    <aside
      className={`sidebar${expanded ? ' expanded' : ''}`}
      onMouseEnter={handleMouseEnter}
      onMouseLeave={handleMouseLeave}
    >
      <div className="sidebar-brand">
        <img src="https://via.placeholder.com/32x32?text=A" alt="Logo" className="sidebar-brand-logo" decoding="async" />
        <span className="sidebar-brand-name sidebar-text">Aryan Nirala</span>
      </div>

      {items.map((item) => {
        const pageKey = item.key === 'accounts' ? 'account' : item.key;
        const isActive = state.sidebarActive === pageKey || (item.key === 'notes' && state.page === 'notes');
        return (
          <a
            key={item.key}
            className={`sidebar-item${isActive ? ' active' : ''}`}
            href={`#${item.key}`}
            onClick={(e) => {
              e.preventDefault();
              goTo(pageKey);
            }}
          >
            {item.avatar ? (
              <div className="profile-avatar" title="Profile">
                {state.account.avatarDataUrl ? (
                  <CroppedAvatar dataUrl={state.account.avatarDataUrl} crop={state.account.avatarCrop} size={36} />
                ) : (
                  'AN'
                )}
              </div>
            ) : (
              <i className={`fas ${item.icon}`}></i>
            )}
            <span className="sidebar-text">{item.label}</span>
          </a>
        );
      })}
    </aside>
  );
}
