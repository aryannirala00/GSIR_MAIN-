import React, { useRef, useState } from 'react';
import { useAppState, useAppDispatch } from '../context/AppContext.jsx';
import { MAX_WEBLINKS } from '../context/reducer.js';
import { normalizeUrl } from '../utils/time.js';

export default function WeblinkPanel() {
  const state = useAppState();
  const dispatch = useAppDispatch();
  const [modalOpen, setModalOpen] = useState(false);
  const [name, setName] = useState('');
  const [url, setUrl] = useState('');
  const dragFromIndex = useRef(null);
  const nameInputRef = useRef(null);

  const openModal = () => {
    setName('');
    setUrl('');
    setModalOpen(true);
    setTimeout(() => nameInputRef.current?.focus(), 0);
  };

  const save = () => {
    const normalized = normalizeUrl(url);
    if (!normalized || state.weblinks.length >= MAX_WEBLINKS) return;

    let fallbackName;
    try {
      fallbackName = new URL(normalized).hostname.replace(/^www\./, '');
    } catch {
      fallbackName = normalized;
    }

    dispatch({ type: 'ADD_WEBLINK', name: name.trim() || fallbackName, url: normalized });
    setModalOpen(false);
  };

  const onFieldKeyDown = (e) => {
    if (e.key === 'Enter') { e.preventDefault(); save(); }
    if (e.key === 'Escape') { e.preventDefault(); setModalOpen(false); }
  };

  const openCard = (link) => {
    window.open(link.url, '_blank'); // opens the actual site in a new browser tab
    dispatch({ type: 'CREATE_TAB', label: link.name, icon: 'fa-globe', tabType: 'chat' }); // mirrors it as a tab here
  };

  const onDragStart = (i) => { dragFromIndex.current = i; };
  const onDrop = (dropIndex) => {
    if (dragFromIndex.current === null || dragFromIndex.current === dropIndex) return;
    const list = state.weblinks.slice();
    const [moved] = list.splice(dragFromIndex.current, 1);
    list.splice(dropIndex, 0, moved);
    dispatch({ type: 'REORDER_WEBLINKS', weblinks: list });
    dragFromIndex.current = null;
  };

  return (
    <>
      <div className="weblink-panel active" id="weblinkPanel">
        <div className="weblink-header">
          <h2>Quick Access Web Links</h2>
          <span className="weblink-count" id="weblinkCount">{state.weblinks.length} / {MAX_WEBLINKS}</span>
        </div>

        <div className="weblink-grid" id="weblinkGrid">
          {state.weblinks.map((link, i) => (
            <div
              key={link.id}
              className="weblink-card"
              draggable
              title={link.url}
              onClick={() => openCard(link)}
              onDragStart={() => onDragStart(i)}
              onDragOver={(e) => e.preventDefault()}
              onDrop={() => onDrop(i)}
            >
              <button
                className="weblink-remove"
                title="Remove"
                onClick={(e) => { e.stopPropagation(); dispatch({ type: 'REMOVE_WEBLINK', id: link.id }); }}
              >
                <i className="fas fa-xmark"></i>
              </button>
              <img src={`https://www.google.com/s2/favicons?sz=64&domain=${encodeURIComponent(link.name)}`} alt="" />
              <span className="weblink-name">{link.name}</span>
            </div>
          ))}

          {state.weblinks.length < MAX_WEBLINKS && (
            <div className="weblink-add-tile" id="weblinkAddTile" onClick={openModal}>
              <i className="fas fa-plus"></i>
              <span>Add shortcut</span>
            </div>
          )}
        </div>
      </div>

      {modalOpen && (
        <div className="shortcut-overlay active" id="shortcutOverlay" onClick={(e) => { if (e.target.id === 'shortcutOverlay') setModalOpen(false); }}>
          <div className="shortcut-modal">
            <h3>Add shortcut</h3>

            <label className="shortcut-label" htmlFor="shortcutName">Name</label>
            <input
              ref={nameInputRef}
              type="text"
              className="shortcut-field"
              id="shortcutName"
              autoComplete="off"
              value={name}
              onChange={(e) => setName(e.target.value)}
              onKeyDown={onFieldKeyDown}
            />

            <label className="shortcut-label" htmlFor="shortcutUrl">URL</label>
            <input
              type="text"
              className="shortcut-field"
              id="shortcutUrl"
              placeholder="https://"
              autoComplete="off"
              value={url}
              onChange={(e) => setUrl(e.target.value)}
              onKeyDown={onFieldKeyDown}
            />

            <div className="shortcut-actions">
              <button className="shortcut-btn shortcut-btn-cancel" onClick={() => setModalOpen(false)}>Cancel</button>
              <button className="shortcut-btn shortcut-btn-done" onClick={save}>Done</button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
