import React, { useMemo, useState } from 'react';
import { useAppState, useAppDispatch } from '../context/AppContext.jsx';

const STATIC_GROUPS = [
  { title: 'Yesterday', items: ['React Component Patterns'] },
  { title: 'Last Week', items: ['API Design Best Practices', 'Database Optimization Tips', 'JavaScript Async/Await'] },
  { title: 'Earlier', items: ['Web Performance Metrics', 'CSS Grid Layout Guide', 'REST API Standards'] },
];

export default function HistoryPanel() {
  const state = useAppState();
  const dispatch = useAppDispatch();
  const [filter, setFilter] = useState('');

  const groups = useMemo(() => {
    const recent = state.searchHistory.length
      ? [{ title: 'This session', items: state.searchHistory }]
      : [];
    return [...recent, ...STATIC_GROUPS];
  }, [state.searchHistory]);

  const loadIntoSearch = (text) => {
    dispatch({ type: 'SET_TAB_QUERY', query: text });
    dispatch({ type: 'SET_PAGE', page: 'home' });
    dispatch({ type: 'TOGGLE_HISTORY_PANEL' });
  };

  return (
    <div className={`history-panel${state.historyPanelOpen ? ' active' : ''}`} id="historyPanel">
      <div className="panel-header">
        <h3 className="panel-title">History</h3>
        <button className="panel-close" id="historyClose" onClick={() => dispatch({ type: 'TOGGLE_HISTORY_PANEL' })}>✕</button>
      </div>

      <div className="history-search">
        <input type="text" placeholder="Search history..." id="historySearchInput" value={filter} onChange={(e) => setFilter(e.target.value)} />
      </div>

      <div className="panel-content">
        {groups.map((group) => {
          const visible = group.items.filter((t) => t.toLowerCase().includes(filter.toLowerCase()));
          if (!visible.length) return null;
          return (
            <div className="history-group" key={group.title}>
              <div className="history-group-title">{group.title}</div>
              {visible.map((text, i) => (
                <div className="history-item" key={i} onClick={() => loadIntoSearch(text)}>{text}</div>
              ))}
            </div>
          );
        })}
      </div>
    </div>
  );
}
