import React from 'react';
import { useAppState } from '../context/AppContext.jsx';
import SearchView from './SearchView.jsx';
import TabContentPane from './TabContentPane.jsx';

export default function HomeView() {
  const state = useAppState();
  const activeTab = state.tabs.find((t) => t.id === state.activeTabId) || state.tabs[0];
  const hasConversation = activeTab.type === 'chat' && activeTab.conversation.length > 0;

  return (
    <div className={`content${hasConversation ? ' has-conversation' : ''}`}>
      {activeTab.type === 'chat' ? <SearchView tab={activeTab} /> : <TabContentPane tab={activeTab} />}
    </div>
  );
}
