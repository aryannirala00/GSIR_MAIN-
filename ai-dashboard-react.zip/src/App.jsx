import React from 'react';
import { useAppState } from './context/AppContext.jsx';
import Sidebar from './components/Sidebar.jsx';
import Header from './components/Header.jsx';
import HomeView from './components/HomeView.jsx';
import WeblinkPanel from './components/WeblinkPanel.jsx';
import AccountPage from './components/Account/AccountPage.jsx';
import SettingsPage from './components/Settings/SettingsPage.jsx';
import NotesPage from './components/Notes/NotesPage.jsx';
import ProjectsPage from './components/Projects/ProjectsPage.jsx';
import HistoryPanel from './components/HistoryPanel.jsx';
import NotificationPanel from './components/NotificationPanel.jsx';
import ToastStack from './components/ToastStack.jsx';

export default function App() {
  const state = useAppState();

  return (
    <>
      <Sidebar />
      <Header />

      <div className="main-container">
        {state.page === 'home' && <HomeView />}
        {state.page === 'weblink' && <WeblinkPanel />}
        {state.page === 'account' && <AccountPage />}
        {state.page === 'settings' && <SettingsPage />}
        {state.page === 'notes' && <NotesPage />}
        {state.page === 'projects' && <ProjectsPage />}
      </div>

      <HistoryPanel />
      <NotificationPanel />
      <ToastStack />
    </>
  );
}
