// Maps a file/link name to a Font Awesome icon class, purely by extension.
// Ported 1:1 from the original vanilla-JS getIconForName().
export function getIconForName(name = '') {
  const ext = name.split('.').pop().toLowerCase();
  const map = {
    pdf: 'fa-file-pdf',
    doc: 'fa-file-word',
    docx: 'fa-file-word',
    xls: 'fa-file-excel',
    xlsx: 'fa-file-excel',
    ppt: 'fa-file-powerpoint',
    pptx: 'fa-file-powerpoint',
    png: 'fa-file-image',
    jpg: 'fa-file-image',
    jpeg: 'fa-file-image',
    gif: 'fa-file-image',
    webp: 'fa-file-image',
    zip: 'fa-file-zipper',
    rar: 'fa-file-zipper',
    txt: 'fa-file-lines',
    csv: 'fa-file-csv',
    mp4: 'fa-file-video',
    mov: 'fa-file-video',
    mp3: 'fa-file-audio',
    wav: 'fa-file-audio',
  };
  return map[ext] || 'fa-file';
}
