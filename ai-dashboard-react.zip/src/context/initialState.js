import { makeId } from '../utils/time.js';

// Two chat tabs to start, matching the original dashboard's default state.
const defaultTabs = [
  { id: 'tab-1', label: 'Tab 1', icon: 'fa-comment', type: 'chat', payload: null, conversation: [], query: '', attachedFiles: [], projectId: null },
  { id: 'tab-2', label: 'Tab 2', icon: 'fa-comment', type: 'chat', payload: null, conversation: [], query: '', attachedFiles: [], projectId: null },
];

export const initialState = {
  page: 'home', // 'home' | 'weblink' | 'account' | 'settings' | 'notes' | 'projects'
  previousPage: 'home', // where Notes should snap back to when toggled closed
  sidebarActive: 'home',
  darkMode: false,
  fontSize: 'medium', // 'small' | 'medium' | 'large'

  tabs: defaultTabs,
  activeTabId: 'tab-1',

  weblinks: [],

  projects: [],
  activeProjectId: null,
  projectWizardOpen: false,
  projectWizardStep: 1,

  notes: [],
  activeNoteId: null,
  notesEditorOpen: false,

  account: {
    locked: true,
    dirty: false,
    profile: {
      name: '',
      age: '',
      gender: '',
      dob: '',
      bio: '',
      researchInterests: [],
    },
    contactWork: {
      mobile: '',
      email: '',
      country: '',
      state: '',
      city: '',
      organization: '',
      department: '',
      designation: '',
      workId: '',
      experience: '',
      licensedChemicals: false,
    },
    laboratory: {
      licenseNumber: '',
      licenseExpiry: '',
      labName: '',
      labOrg: '',
      labType: '',
      address: '',
      mapsUrl: '',
      workingDays: '',
      openTime: '',
      closeTime: '',
      equipmentList: [],
      ratings: { Cleanliness: 0, Safety: 0, Equipment: 0, Staff: 0 },
      reviewTitle: '',
      reviewDescription: '',
      reviewImages: [],
    },
    supplier: {
      company: '',
      website: '',
      location: '',
      contact: '',
      description: '',
      isSupplier: false,
    },
    avatarDataUrl: null,
    avatarCrop: null,
  },

  settings: {
    memory: true,
    autoLocation: false,
    autoSuggestions: true,
    webSearch: true,
    voiceResponse: false,
    twoFA: false,
    creativity: 50,
  },

  toasts: [],
  historyPanelOpen: false,
  notificationPanelOpen: false,
  searchHistory: [],
};

export function newTabId() {
  return makeId('tab');
}
