import { makeId } from '../utils/time.js';

export const MAX_TABS = 15;
export const MAX_WEBLINKS = 10;

function withActiveTab(state, fn) {
  const idx = state.tabs.findIndex((t) => t.id === state.activeTabId);
  if (idx === -1) return state;
  const tabs = state.tabs.slice();
  tabs[idx] = fn(tabs[idx]);
  return { ...state, tabs };
}

export function reducer(state, action) {
  switch (action.type) {
    // ---------- NAVIGATION ----------
    case 'SET_PAGE': {
      if (action.page === 'notes' && state.page !== 'notes') {
        return { ...state, previousPage: state.page, page: 'notes', sidebarActive: 'notes' };
      }
      return { ...state, page: action.page, sidebarActive: action.page };
    }
    case 'CLOSE_NOTES_TO_PREVIOUS':
      return { ...state, page: state.previousPage, sidebarActive: state.previousPage };

    // ---------- THEME / ACCESSIBILITY ----------
    case 'TOGGLE_DARK_MODE':
      return { ...state, darkMode: !state.darkMode };
    case 'SET_DARK_MODE':
      return { ...state, darkMode: action.value };
    case 'SET_FONT_SIZE':
      return { ...state, fontSize: action.size };

    // ---------- TABS ----------
    case 'CREATE_TAB': {
      if (state.tabs.length >= MAX_TABS) return state;
      const id = makeId('tab');
      const tab = {
        id,
        label: action.label || 'New tab',
        icon: action.icon || 'fa-comment',
        type: action.tabType || 'chat',
        payload: action.payload || null,
        conversation: action.conversation || [],
        query: '',
        attachedFiles: [],
        projectId: action.projectId || null,
      };
      return { ...state, tabs: [...state.tabs, tab], activeTabId: id, page: 'home' };
    }
    case 'CLOSE_TAB': {
      const closingIdx = state.tabs.findIndex((t) => t.id === action.id);
      if (closingIdx === -1) return state;
      let tabs = state.tabs.filter((t) => t.id !== action.id);
      const wasActive = state.activeTabId === action.id;
      if (!tabs.length) {
        tabs = [{ id: makeId('tab'), label: 'Tab 1', icon: 'fa-comment', type: 'chat', payload: null, conversation: [], query: '', attachedFiles: [] }];
      }
      const activeTabId = wasActive ? tabs[tabs.length - 1].id : state.activeTabId;
      return { ...state, tabs, activeTabId, page: wasActive ? 'home' : state.page };
    }
    case 'SWITCH_TAB':
      return { ...state, activeTabId: action.id, page: 'home' };
    case 'RENAME_ACTIVE_TAB':
      return withActiveTab(state, (t) => ({ ...t, label: action.label, icon: action.icon || t.icon }));
    case 'SET_TAB_QUERY':
      return withActiveTab(state, (t) => ({ ...t, query: action.query }));
    case 'ADD_TAB_MESSAGE':
      return withActiveTab(state, (t) => ({ ...t, conversation: [...t.conversation, action.message] }));
    case 'MARK_TAB_MESSAGE_COMPLETE':
      return withActiveTab(state, (t) => ({
        ...t,
        conversation: t.conversation.map((m, i) => (i === action.index ? { ...m, incomplete: false } : m)),
      }));
    case 'TOGGLE_TAB_MESSAGE_LIKE':
      return withActiveTab(state, (t) => ({
        ...t,
        conversation: t.conversation.map((m, i) => (i === action.index ? { ...m, liked: !m.liked } : m)),
      }));
    case 'ADD_TAB_ATTACHMENT':
      return withActiveTab(state, (t) => ({ ...t, attachedFiles: [...t.attachedFiles, action.file] }));
    case 'REMOVE_TAB_ATTACHMENT':
      return withActiveTab(state, (t) => ({ ...t, attachedFiles: t.attachedFiles.filter((_, i) => i !== action.index) }));
    case 'CLEAR_TAB_ATTACHMENTS':
      return withActiveTab(state, (t) => ({ ...t, attachedFiles: [] }));

    // ---------- WEBLINKS ----------
    case 'ADD_WEBLINK': {
      if (state.weblinks.length >= MAX_WEBLINKS) return state;
      return { ...state, weblinks: [...state.weblinks, { id: makeId('link'), name: action.name, url: action.url }] };
    }
    case 'REMOVE_WEBLINK':
      return { ...state, weblinks: state.weblinks.filter((l) => l.id !== action.id) };
    case 'REORDER_WEBLINKS':
      return { ...state, weblinks: action.weblinks };

    // ---------- PROJECTS ----------
    case 'OPEN_PROJECT_WIZARD':
      return { ...state, projectWizardOpen: true, projectWizardStep: 1 };
    case 'CLOSE_PROJECT_WIZARD':
      return { ...state, projectWizardOpen: false, projectWizardStep: 1 };
    case 'SET_PROJECT_WIZARD_STEP':
      return { ...state, projectWizardStep: action.step };
    case 'CREATE_PROJECT': {
      const project = {
        id: action.project.id || makeId('proj'),
        name: action.project.name,
        description: action.project.description,
        goal: action.project.goal,
        info: action.project.info,
        files: action.project.files || [],
        chatHistory: [],
      };
      return {
        ...state,
        projects: [...state.projects, project],
        projectWizardOpen: false,
        projectWizardStep: 1,
      };
    }
    case 'DELETE_PROJECT':
      return {
        ...state,
        projects: state.projects.filter((p) => p.id !== action.id),
        activeProjectId: state.activeProjectId === action.id ? null : state.activeProjectId,
      };
    case 'OPEN_PROJECT_DETAIL':
      return { ...state, activeProjectId: action.id };
    case 'CLOSE_PROJECT_DETAIL':
      return { ...state, activeProjectId: null };
    case 'UPDATE_PROJECT_FIELDS':
      return {
        ...state,
        projects: state.projects.map((p) => (p.id === action.id ? { ...p, ...action.fields } : p)),
      };
    case 'ADD_PROJECT_FILE':
      return {
        ...state,
        projects: state.projects.map((p) => (p.id === action.id ? { ...p, files: [...p.files, action.file] } : p)),
      };
    case 'REMOVE_PROJECT_FILE':
      return {
        ...state,
        projects: state.projects.map((p) =>
          p.id === action.id ? { ...p, files: p.files.filter((_, i) => i !== action.index) } : p
        ),
      };
    case 'RENAME_PROJECT_FILE':
      return {
        ...state,
        projects: state.projects.map((p) =>
          p.id === action.id
            ? { ...p, files: p.files.map((f, i) => (i === action.index ? { ...f, name: action.name } : f)) }
            : p
        ),
      };

    // ---------- NOTES ----------
    case 'OPEN_NOTE_EDITOR':
      return { ...state, activeNoteId: action.id || null, notesEditorOpen: true };
    case 'CLOSE_NOTE_EDITOR':
      return { ...state, activeNoteId: null, notesEditorOpen: false };
    case 'SAVE_NOTE': {
      const now = Date.now();
      if (action.id) {
        return {
          ...state,
          notes: state.notes.map((n) => (n.id === action.id ? { ...n, title: action.title, content: action.content, updatedAt: now } : n)),
          notesEditorOpen: false,
          activeNoteId: null,
        };
      }
      const note = { id: makeId('note'), title: action.title, content: action.content, updatedAt: now };
      return { ...state, notes: [note, ...state.notes], notesEditorOpen: false, activeNoteId: null };
    }
    case 'DELETE_NOTE':
      return { ...state, notes: state.notes.filter((n) => n.id !== action.id), notesEditorOpen: false, activeNoteId: null };
    case 'RENAME_NOTE':
      return { ...state, notes: state.notes.map((n) => (n.id === action.id ? { ...n, title: action.title, updatedAt: Date.now() } : n)) };

    // ---------- ACCOUNT ----------
    case 'UNLOCK_ACCOUNT':
      return { ...state, account: { ...state.account, locked: false } };
    case 'LOCK_ACCOUNT':
      return { ...state, account: { ...state.account, locked: true, dirty: false } };
    case 'SET_ACCOUNT_DIRTY':
      return { ...state, account: { ...state.account, dirty: action.value } };
    case 'UPDATE_ACCOUNT_SECTION':
      return {
        ...state,
        account: {
          ...state.account,
          [action.section]: { ...state.account[action.section], ...action.fields },
          dirty: true,
        },
      };
    case 'TOGGLE_RESEARCH_INTEREST': {
      const current = state.account.profile.researchInterests;
      const has = current.includes(action.value);
      const next = has ? current.filter((v) => v !== action.value) : [...current, action.value];
      return {
        ...state,
        account: { ...state.account, dirty: true, profile: { ...state.account.profile, researchInterests: next } },
      };
    }
    case 'ADD_EQUIPMENT':
      return {
        ...state,
        account: {
          ...state.account,
          dirty: true,
          laboratory: { ...state.account.laboratory, equipmentList: [...state.account.laboratory.equipmentList, action.name] },
        },
      };
    case 'REMOVE_EQUIPMENT':
      return {
        ...state,
        account: {
          ...state.account,
          dirty: true,
          laboratory: {
            ...state.account.laboratory,
            equipmentList: state.account.laboratory.equipmentList.filter((_, i) => i !== action.index),
          },
        },
      };
    case 'SET_LAB_RATING':
      return {
        ...state,
        account: {
          ...state.account,
          dirty: true,
          laboratory: { ...state.account.laboratory, ratings: { ...state.account.laboratory.ratings, [action.category]: action.value } },
        },
      };
    case 'ADD_REVIEW_IMAGE':
      return {
        ...state,
        account: {
          ...state.account,
          dirty: true,
          laboratory: { ...state.account.laboratory, reviewImages: [...state.account.laboratory.reviewImages, action.name] },
        },
      };
    case 'REMOVE_REVIEW_IMAGE':
      return {
        ...state,
        account: {
          ...state.account,
          dirty: true,
          laboratory: { ...state.account.laboratory, reviewImages: state.account.laboratory.reviewImages.filter((_, i) => i !== action.index) },
        },
      };
    case 'SET_AVATAR':
      return { ...state, account: { ...state.account, avatarDataUrl: action.dataUrl, avatarCrop: action.crop, dirty: true } };
    case 'SAVE_ACCOUNT':
      return { ...state, account: { ...state.account, locked: true, dirty: false } };

    // ---------- SETTINGS ----------
    case 'UPDATE_SETTING':
      return { ...state, settings: { ...state.settings, [action.key]: action.value } };

    // ---------- TOASTS ----------
    case 'SHOW_TOAST':
      return { ...state, toasts: [...state.toasts, { id: makeId('toast'), message: action.message, kind: action.kind || 'info' }] };
    case 'DISMISS_TOAST':
      return { ...state, toasts: state.toasts.filter((t) => t.id !== action.id) };

    // ---------- PANELS ----------
    case 'TOGGLE_HISTORY_PANEL':
      return { ...state, historyPanelOpen: !state.historyPanelOpen, notificationPanelOpen: false };
    case 'TOGGLE_NOTIFICATION_PANEL':
      return { ...state, notificationPanelOpen: !state.notificationPanelOpen, historyPanelOpen: false };
    case 'CLOSE_PANELS':
      return { ...state, historyPanelOpen: false, notificationPanelOpen: false };
    case 'ADD_SEARCH_HISTORY':
      return { ...state, searchHistory: [action.query, ...state.searchHistory].slice(0, 50) };

    case 'HYDRATE':
      return { ...state, ...action.state };

    default:
      return state;
  }
}
