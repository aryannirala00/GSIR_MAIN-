import React, { createContext, useContext, useEffect, useReducer, useRef } from 'react';
import { reducer } from './reducer.js';
import { initialState } from './initialState.js';

const STORAGE_KEY = 'ai-dashboard-state-v1';

const AppStateContext = createContext(null);
const AppDispatchContext = createContext(null);

function loadPersisted() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw);
    // Only trust the slices we actually want to persist across reloads —
    // tabs/panels/toasts stay fresh each session.
    return {
      darkMode: parsed.darkMode,
      fontSize: parsed.fontSize,
      weblinks: parsed.weblinks,
      projects: parsed.projects,
      notes: parsed.notes,
      account: parsed.account,
      settings: parsed.settings,
      searchHistory: parsed.searchHistory,
    };
  } catch {
    return null; // corrupted/old localStorage shape — start fresh rather than crash
  }
}

export function AppProvider({ children }) {
  const [state, dispatch] = useReducer(reducer, initialState);
  const hydrated = useRef(false);

  useEffect(() => {
    const persisted = loadPersisted();
    if (persisted) dispatch({ type: 'HYDRATE', state: persisted });
    hydrated.current = true;
  }, []);

  useEffect(() => {
    if (!hydrated.current) return; // don't overwrite storage with initialState before hydration runs
    const toSave = {
      darkMode: state.darkMode,
      fontSize: state.fontSize,
      weblinks: state.weblinks,
      projects: state.projects,
      notes: state.notes,
      account: state.account,
      settings: state.settings,
      searchHistory: state.searchHistory,
    };
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(toSave));
    } catch {
      // storage full or unavailable (private browsing) — fail silently, nothing to recover here
    }
  }, [state.darkMode, state.fontSize, state.weblinks, state.projects, state.notes, state.account, state.settings, state.searchHistory]);

  useEffect(() => {
    // bug fix: this used to set data-theme/data-font-size attributes on
    // <html>, but the ported CSS actually keys off classes on <body>
    // (body.dark-theme, body.app-font-small/app-font-large — same
    // mechanism the original vanilla-JS version used). As written, the
    // Dark Mode toggle and Font Size selector in Settings had no visual
    // effect at all.
    document.body.classList.toggle('dark-theme', state.darkMode);
    document.body.classList.remove('app-font-small', 'app-font-large');
    if (state.fontSize === 'small') document.body.classList.add('app-font-small');
    else if (state.fontSize === 'large') document.body.classList.add('app-font-large');
  }, [state.darkMode, state.fontSize]);

  return (
    <AppStateContext.Provider value={state}>
      <AppDispatchContext.Provider value={dispatch}>{children}</AppDispatchContext.Provider>
    </AppStateContext.Provider>
  );
}

export function useAppState() {
  const ctx = useContext(AppStateContext);
  if (!ctx) throw new Error('useAppState must be used within AppProvider');
  return ctx;
}

export function useAppDispatch() {
  const ctx = useContext(AppDispatchContext);
  if (!ctx) throw new Error('useAppDispatch must be used within AppProvider');
  return ctx;
}

// Small convenience hook for firing toasts from anywhere.
export function useToast() {
  const dispatch = useAppDispatch();
  return (message, kind = 'info') => dispatch({ type: 'SHOW_TOAST', message, kind });
}
